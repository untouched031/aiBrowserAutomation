╔═══════════════════════════════════════════════════════════════╗
║           C O D E B A S E   D O C U M E N T A T I O N          ║
╚═══════════════════════════════════════════════════════════════╝

Generated: 2026-11-07 11:52:44
Root Path: C:\.scripts\browserAutomations\aiBrowserAutomation
Excluded: node_modules, .git, bin, obj, dist, build, .vs, packages, target, out, .next, .nuxt, coverage

┌───────────────────────────────────────────────────────────────┐
│                    PROJECT STRUCTURE                          │
└───────────────────────────────────────────────────────────────┘

aiBrowserAutomation/
├── Config/
│   └── config.json
├── Logs/
│   └── automation.log
├── Prompts/
│   └── prompt.txt
├── Scripts/
│   ├── Get-MousePosition.ps1
│   ├── Install-ScheduledTask.ps1
│   ├── Invoke-AIBrowserAutomation.ps1
│   ├── ProviderDetection.ps1
│   ├── Test-UrlDetection.ps1
│   └── Uninstall-ScheduledTask.ps1
└── README.md

┌───────────────────────────────────────────────────────────────┐
│                     FILE CONTENTS                             │
└───────────────────────────────────────────────────────────────┘

═══════════════════════════════════════════════════════════════
FILE: Config\config.json
SIZE: 2.32 KB | LINES: 80
TYPE: json
═══════════════════════════════════════════════════════════════
```json
{
  "TargetUrl": "https://claude.ai/new",
  "BrowserExecutable": "",

  "PromptFilePath": "Prompts/prompt.txt",
  "FilesToAttach": [],
  "UseFileAttachment": false,

  "MaximizeBrowserWindow": true,

  "WaitAfterLaunchSeconds": 8,
  "WaitAfterFocusSeconds": 1,
  "WaitAfterAttachClickSeconds": 2,
  "WaitAfterFileTypedSeconds": 2,
  "WaitBeforeSubmitSeconds": 1,

  "SubmitKeystroke": "{ENTER}",

  "DefaultOngoingIdPattern": "[0-9a-fA-F-]{20,}",

  "Providers": [
    {
      "Name": "Claude",
      "DomainMatch": "claude.ai",
      "BrowserWindowTitleMatch": "Claude",
      "NewChatKeywords": ["new"],
      "OngoingPattern": "",
      "Coordinates": {
        "New": {
          "PromptBoxClick": { "Enabled": true, "X": 0, "Y": 0 },
          "AttachButtonClick": { "Enabled": false, "X": 0, "Y": 0 },
          "AttachButtonTabPresses": 0
        },
        "Ongoing": {
          "PromptBoxClick": { "Enabled": true, "X": 0, "Y": 0 },
          "AttachButtonClick": { "Enabled": false, "X": 0, "Y": 0 },
          "AttachButtonTabPresses": 0
        }
      }
    },
    {
      "Name": "ChatGPT",
      "DomainMatch": "chatgpt.com",
      "BrowserWindowTitleMatch": "ChatGPT",
      "NewChatKeywords": ["new"],
      "OngoingPattern": "",
      "Coordinates": {
        "New": {
          "PromptBoxClick": { "Enabled": true, "X": 0, "Y": 0 },
          "AttachButtonClick": { "Enabled": false, "X": 0, "Y": 0 },
          "AttachButtonTabPresses": 0
        },
        "Ongoing": {
          "PromptBoxClick": { "Enabled": true, "X": 0, "Y": 0 },
          "AttachButtonClick": { "Enabled": false, "X": 0, "Y": 0 },
          "AttachButtonTabPresses": 0
        }
      }
    },
    {
      "Name": "Kimi",
      "DomainMatch": "kimi.ai",
      "BrowserWindowTitleMatch": "Kimi",
      "NewChatKeywords": ["new"],
      "OngoingPattern": "",
      "Coordinates": {
        "New": {
          "PromptBoxClick": { "Enabled": true, "X": 0, "Y": 0 },
          "AttachButtonClick": { "Enabled": false, "X": 0, "Y": 0 },
          "AttachButtonTabPresses": 0
        },
        "Ongoing": {
          "PromptBoxClick": { "Enabled": true, "X": 0, "Y": 0 },
          "AttachButtonClick": { "Enabled": false, "X": 0, "Y": 0 },
          "AttachButtonTabPresses": 0
        }
      }
    }
  ]
}
```


═══════════════════════════════════════════════════════════════
FILE: Logs\automation.log
SIZE: 0 KB | LINES: 0
TYPE: plaintext
═══════════════════════════════════════════════════════════════
```plaintext
[Empty File]
```


═══════════════════════════════════════════════════════════════
FILE: Prompts\prompt.txt
SIZE: 0 KB | LINES: 0
TYPE: plaintext
═══════════════════════════════════════════════════════════════
```plaintext
[Empty File]
```


═══════════════════════════════════════════════════════════════
FILE: Scripts\Get-MousePosition.ps1
SIZE: 0.67 KB | LINES: 19
TYPE: powershell
═══════════════════════════════════════════════════════════════
```powershell
<#
.SYNOPSIS
    Prints the live screen coordinates of the mouse cursor, so you can find
    the X / Y values for PromptBoxClick / AttachButtonClick in config.json.

.DESCRIPTION
    Run this, then hover the mouse over the chat input box (or the
    attach-file button) in the browser and read the X/Y printed in the
    console. Press Ctrl+C to stop.
#>

Add-Type -AssemblyName System.Windows.Forms

Write-Host "Hover the mouse over the target element. Press Ctrl+C to stop." -ForegroundColor Cyan
while ($true) {
    $pos = [System.Windows.Forms.Cursor]::Position
    Write-Host ("`rX = {0,5}   Y = {1,5}" -f $pos.X, $pos.Y) -NoNewline
    Start-Sleep -Milliseconds 200
}
```


═══════════════════════════════════════════════════════════════
FILE: Scripts\Install-ScheduledTask.ps1
SIZE: 2.68 KB | LINES: 69
TYPE: powershell
═══════════════════════════════════════════════════════════════
```powershell
<#
.SYNOPSIS
    Registers (or re-registers) the Windows scheduled task that runs the
    AI browser automation project at a chosen time.

.EXAMPLE
    .\Install-ScheduledTask.ps1 -Time "09:00"

.EXAMPLE
    .\Install-ScheduledTask.ps1 -Time "18:30" -Frequency Weekly -DaysOfWeek Monday,Wednesday,Friday

.EXAMPLE
    .\Install-ScheduledTask.ps1 -Time "07:00" -TaskName "MorningDigest" -ConfigPath "C:\.scripts\browserAutomations\aiBrowserAutomation\Config\config.morning.json"
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidatePattern('^\d{1,2}:\d{2}$')]
    [string]$Time,

    [ValidateSet("Daily", "Weekly")]
    [string]$Frequency = "Daily",

    [ValidateSet("Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday")]
    [string[]]$DaysOfWeek = @("Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"),

    [string]$TaskName = "AIBrowserAutomation",

    [string]$ConfigPath
)

$ErrorActionPreference = "Stop"

$ProjectRoot = Split-Path -Parent $PSScriptRoot
$MainScript  = Join-Path $PSScriptRoot "Invoke-AIBrowserAutomation.ps1"

if (-not (Test-Path $MainScript)) {
    throw "Could not find main script at: $MainScript"
}

$LogsDir = Join-Path $ProjectRoot "Logs"
if (-not (Test-Path $LogsDir)) { New-Item -ItemType Directory -Path $LogsDir -Force | Out-Null }

$PowerShellExe = (Get-Command powershell.exe).Source

$ArgList = "-NoProfile -ExecutionPolicy Bypass -WindowStyle Normal -File `"$MainScript`""
if ($ConfigPath) {
    $ArgList += " -ConfigPath `"$ConfigPath`""
}

$Action = New-ScheduledTaskAction -Execute $PowerShellExe -Argument $ArgList -WorkingDirectory $ProjectRoot

$NormalizedTime = $Time.PadLeft(5, '0')
$ParsedTime = [DateTime]::ParseExact($NormalizedTime, "HH:mm", [System.Globalization.CultureInfo]::InvariantCulture)

if ($Frequency -eq "Daily") {
    $Trigger = New-ScheduledTaskTrigger -Daily -At $ParsedTime
} else {
    $Trigger = New-ScheduledTaskTrigger -Weekly -DaysOfWeek $DaysOfWeek -At $ParsedTime
}

$Principal = New-ScheduledTaskPrincipal -UserId "$env:USERDOMAIN\$env:USERNAME" -LogonType Interactive -RunLevel Limited

$Settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable -ExecutionTimeLimit (New-TimeSpan -Hours 1)

Register-ScheduledTask -TaskName $TaskName -Action $Action -Trigger $Trigger -Principal $Principal -Settings $Settings -Description "aiBrowserAutomation: opens a browser, pastes a prompt, optionally attaches files, and submits it." -Force | Out-Null

Write-Host "Scheduled task '$TaskName' installed: $Frequency at $Time, running as $env:USERNAME (requires an unlocked, logged-in session)."
```


═══════════════════════════════════════════════════════════════
FILE: Scripts\Invoke-AIBrowserAutomation.ps1
SIZE: 9.98 KB | LINES: 244
TYPE: powershell
═══════════════════════════════════════════════════════════════
```powershell
<#
.SYNOPSIS
    Opens a target URL in the browser, detects which AI provider and which
    chat state (new vs ongoing) that URL belongs to, optionally attaches
    files, pastes a prompt loaded from a text file, and submits it.

.DESCRIPTION
    Meant to be triggered by a Windows scheduled task (see
    Install-ScheduledTask.ps1). Every path is resolved relative to this
    script's own location ($PSScriptRoot), so the whole project folder can
    be copied to any PC and just works, with no usernames or machine-specific
    paths hardcoded anywhere.

    Config\config.json holds a "Providers" array: one entry per AI site
    (Claude, ChatGPT, Kimi, ...), each with its own window-title match and
    two coordinate sets - one for a brand-new chat, one for an ongoing
    (existing) chat. At run time this script looks at TargetUrl, works out
    which provider and which state it is (see ProviderDetection.ps1), and
    uses that provider+state's coordinates automatically. See README.md for
    how detection works and how to add a new provider.

.NOTES
    - This drives the real screen (clipboard + simulated keystrokes/clicks),
      so the PC must be logged in and unlocked when it runs.
    - UI automation is timing- and layout-dependent. Calibrate the
      Wait*Seconds values and each provider's coordinates in
      Config\config.json - see README.md.
#>

[CmdletBinding()]
param(
    [string]$ConfigPath
)

$ErrorActionPreference = "Stop"

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

Add-Type @"
using System;
using System.Runtime.InteropServices;
public class AiBrowserAutomationMouse {
    [DllImport("user32.dll")]
    public static extern void mouse_event(uint dwFlags, uint dx, uint dy, uint dwData, UIntPtr dwExtraInfo);
    public const uint LEFTDOWN = 0x0002;
    public const uint LEFTUP   = 0x0004;
}
"@

# ---------- Paths & logging (set up first, so even an early error gets logged) ----------
$ProjectRoot = Split-Path -Parent $PSScriptRoot
$LogDir  = Join-Path $ProjectRoot "Logs"
$LogFile = Join-Path $LogDir "automation.log"
if (-not (Test-Path $LogDir)) { New-Item -ItemType Directory -Path $LogDir -Force | Out-Null }

function Write-Log {
    param([string]$Message)
    $line = "[{0}] {1}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $Message
    Add-Content -Path $LogFile -Value $line
    Write-Host $line
}

function Resolve-ProjectPath {
    param([string]$PathValue)
    if ([string]::IsNullOrWhiteSpace($PathValue)) { return $null }
    if ([System.IO.Path]::IsPathRooted($PathValue)) { return $PathValue }
    return (Join-Path $ProjectRoot $PathValue)
}

function Send-KeysWait {
    param([string]$Keys, [int]$DelayMs = 150)
    Start-Sleep -Milliseconds $DelayMs
    [System.Windows.Forms.SendKeys]::SendWait($Keys)
}

function Invoke-MouseClick {
    param([int]$X, [int]$Y)
    [System.Windows.Forms.Cursor]::Position = New-Object System.Drawing.Point($X, $Y)
    Start-Sleep -Milliseconds 200
    [AiBrowserAutomationMouse]::mouse_event([AiBrowserAutomationMouse]::LEFTDOWN, 0, 0, 0, [UIntPtr]::Zero)
    Start-Sleep -Milliseconds 80
    [AiBrowserAutomationMouse]::mouse_event([AiBrowserAutomationMouse]::LEFTUP, 0, 0, 0, [UIntPtr]::Zero)
    Start-Sleep -Milliseconds 200
}

function Show-BrowserWindow {
    param([string]$TitleMatch, [int]$TimeoutSeconds = 15)
    if ([string]::IsNullOrWhiteSpace($TitleMatch)) { return $false }
    $shell = New-Object -ComObject WScript.Shell
    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    while ($sw.Elapsed.TotalSeconds -lt $TimeoutSeconds) {
        if ($shell.AppActivate($TitleMatch)) {
            Write-Log "Activated a window matching '$TitleMatch'."
            return $true
        }
        Start-Sleep -Milliseconds 500
    }
    Write-Log "WARNING: no window matching '$TitleMatch' found within $TimeoutSeconds s."
    return $false
}

function Maximize-BrowserWindow {
    # Alt+Space opens the active window's system menu; "x" is the Maximize mnemonic.
    Send-KeysWait -Keys "% " -DelayMs 250
    Send-KeysWait -Keys "x" -DelayMs 250
}

function Get-PromptPayload {
    param([string]$PromptFile)
    if (-not (Test-Path $PromptFile)) {
        throw "Prompt file not found: $PromptFile"
    }
    $raw = Get-Content -Raw -Path $PromptFile
    $pattern = '<<attach:\s*(.+?)\s*>>'
    $regexMatches = [System.Text.RegularExpressions.Regex]::Matches($raw, $pattern)
    $attachments = @()
    foreach ($m in $regexMatches) { $attachments += $m.Groups[1].Value.Trim() }
    $clean = ($raw -replace $pattern, '').Trim()
    [PSCustomObject]@{
        Text        = $clean
        Attachments = $attachments
    }
}

function Test-Calibrated {
    param($Click, [string]$Label)
    if ($Click.Enabled -and $Click.X -eq 0 -and $Click.Y -eq 0) {
        throw "$Label is enabled but still at the placeholder X=0, Y=0. Run Scripts\Get-MousePosition.ps1, hover over the real element, and fill in its X/Y in config.json before running this for real."
    }
}

# ---------- Main ----------
try {
    Write-Log "===== Run started ====="

    . (Join-Path $PSScriptRoot "ProviderDetection.ps1")

    if (-not $ConfigPath) { $ConfigPath = Join-Path $PSScriptRoot "..\Config\config.json" }
    $ConfigPath = (Resolve-Path $ConfigPath).Path
    $Config = Get-Content -Raw -Path $ConfigPath | ConvertFrom-Json

    # Figure out which AI provider TargetUrl belongs to, and whether it's a
    # fresh/new chat or an ongoing one.
    $Provider = Find-Provider -Config $Config -Url $Config.TargetUrl
    if (-not $Provider) {
        throw "No entry under 'Providers' in config.json matches the domain of TargetUrl ('$($Config.TargetUrl)'). Add a new Providers entry with a 'DomainMatch' for this site - see README.md 'Adding a new AI provider'."
    }
    $State = Get-ChatState -Provider $Provider -Url $Config.TargetUrl -DefaultOngoingPattern $Config.DefaultOngoingIdPattern
    $Coords = $Provider.Coordinates.$State
    if (-not $Coords) {
        throw "Provider '$($Provider.Name)' has no Coordinates.$State block in config.json."
    }
    $WindowTitleMatch = $Provider.BrowserWindowTitleMatch
    Write-Log "TargetUrl matched provider '$($Provider.Name)', detected as '$State' chat."

    Test-Calibrated -Click $Coords.PromptBoxClick -Label "$($Provider.Name) / $State / PromptBoxClick"
    if ($Config.UseFileAttachment) {
        Test-Calibrated -Click $Coords.AttachButtonClick -Label "$($Provider.Name) / $State / AttachButtonClick"
    }

    $promptFilePath = Resolve-ProjectPath $Config.PromptFilePath
    $payload = Get-PromptPayload -PromptFile $promptFilePath
    $promptText = $payload.Text

    $allAttachments = @()
    if ($Config.FilesToAttach) { $allAttachments += @($Config.FilesToAttach) }
    if ($payload.Attachments)  { $allAttachments += @($payload.Attachments) }

    if ([string]::IsNullOrWhiteSpace($promptText)) {
        throw "Prompt file is empty (after removing <<attach:...>> tags): $promptFilePath"
    }
    Write-Log "Prompt loaded ($($promptText.Length) chars). Attachments queued: $($allAttachments.Count)."

    # 1) Open the link
    if ([string]::IsNullOrWhiteSpace($Config.BrowserExecutable)) {
        Write-Log "Launching default browser -> $($Config.TargetUrl)"
        Start-Process -FilePath $Config.TargetUrl
    } else {
        Write-Log "Launching '$($Config.BrowserExecutable)' -> $($Config.TargetUrl)"
        Start-Process -FilePath $Config.BrowserExecutable -ArgumentList $Config.TargetUrl
    }
    Start-Sleep -Seconds $Config.WaitAfterLaunchSeconds

    # 2) Bring it to the front (and optionally maximize, for reliable click coordinates)
    Show-BrowserWindow -TitleMatch $WindowTitleMatch | Out-Null
    if ($Config.MaximizeBrowserWindow) { Maximize-BrowserWindow }
    Start-Sleep -Seconds $Config.WaitAfterFocusSeconds

    # 3) Attachments first (most chat UIs keep a file attached while you then type the message)
    if ($Config.UseFileAttachment -and $allAttachments.Count -gt 0) {
        foreach ($filePath in $allAttachments) {
            if (-not (Test-Path $filePath)) {
                Write-Log "WARNING: attachment not found, skipping -> $filePath"
                continue
            }
            Write-Log "Attaching -> $filePath"

            if ($Coords.AttachButtonClick.Enabled) {
                Invoke-MouseClick -X $Coords.AttachButtonClick.X -Y $Coords.AttachButtonClick.Y
            } else {
                for ($i = 0; $i -lt [int]$Coords.AttachButtonTabPresses; $i++) {
                    Send-KeysWait -Keys "{TAB}" -DelayMs 150
                }
                Send-KeysWait -Keys "{ENTER}" -DelayMs 300
            }
            Start-Sleep -Seconds $Config.WaitAfterAttachClickSeconds

            # The OS "Open" dialog's file name field is focused by default.
            Set-Clipboard -Value $filePath
            Send-KeysWait -Keys "^a" -DelayMs 150
            Send-KeysWait -Keys "^v" -DelayMs 150
            Start-Sleep -Milliseconds 500
            Send-KeysWait -Keys "{ENTER}" -DelayMs 150

            Start-Sleep -Seconds $Config.WaitAfterFileTypedSeconds
            Show-BrowserWindow -TitleMatch $WindowTitleMatch | Out-Null
        }
        Start-Sleep -Seconds 1
    }

    # 4) Focus the prompt box
    if ($Coords.PromptBoxClick.Enabled) {
        Invoke-MouseClick -X $Coords.PromptBoxClick.X -Y $Coords.PromptBoxClick.Y
    } else {
        Show-BrowserWindow -TitleMatch $WindowTitleMatch | Out-Null
    }

    # 5) Paste the prompt via the clipboard (handles special characters / line breaks / length cleanly)
    Set-Clipboard -Value $promptText
    Start-Sleep -Milliseconds 400
    Send-KeysWait -Keys "^v" -DelayMs 150
    Start-Sleep -Seconds $Config.WaitBeforeSubmitSeconds

    # 6) Submit
    Send-KeysWait -Keys $Config.SubmitKeystroke -DelayMs 150

    Write-Log "Prompt submitted."
    Write-Log "===== Run finished OK ====="
}
catch {
    Write-Log "ERROR: $($_.Exception.Message)"
    throw
}
```


═══════════════════════════════════════════════════════════════
FILE: Scripts\ProviderDetection.ps1
SIZE: 1.48 KB | LINES: 46
TYPE: powershell
═══════════════════════════════════════════════════════════════
```powershell
<#
.SYNOPSIS
    Shared provider + chat-state detection logic.

.DESCRIPTION
    Dot-sourced by both Invoke-AIBrowserAutomation.ps1 and
    Test-UrlDetection.ps1, so the real run and the dry-run tester can never
    drift out of sync. See README.md "How provider + chat-state detection
    works" for the exact rules.

    Providers are checked in the order they appear in config.json; the
    first whose DomainMatch is found in the URL wins.
#>

function Convert-ToSafeArray {
    param($Value)
    if ($null -eq $Value) { return @() }
    return @($Value)
}

function Find-Provider {
    param($Config, [string]$Url)
    foreach ($p in $Config.Providers) {
        if ([string]::IsNullOrWhiteSpace($p.DomainMatch)) { continue }
        if ($Url -imatch [regex]::Escape($p.DomainMatch)) { return $p }
    }
    return $null
}

function Get-ChatState {
    param($Provider, [string]$Url, [string]$DefaultOngoingPattern)

    $keywords = Convert-ToSafeArray $Provider.NewChatKeywords
    if ($keywords.Count -eq 0) { $keywords = @("new") }

    foreach ($kw in $keywords) {
        if ([string]::IsNullOrWhiteSpace([string]$kw)) { continue }
        if ($Url -imatch [regex]::Escape([string]$kw)) { return "New" }
    }

    $pattern = $Provider.OngoingPattern
    if ([string]::IsNullOrWhiteSpace($pattern)) { $pattern = $DefaultOngoingPattern }
    if (-not [string]::IsNullOrWhiteSpace($pattern) -and $Url -imatch $pattern) { return "Ongoing" }

    return "New"
}
```


═══════════════════════════════════════════════════════════════
FILE: Scripts\Test-UrlDetection.ps1
SIZE: 2.4 KB | LINES: 63
TYPE: powershell
═══════════════════════════════════════════════════════════════
```powershell
<#
.SYNOPSIS
    Dry-run helper: given a URL (or no URL, to use config.json's current
    TargetUrl), prints which provider and chat-state it would be detected
    as - without opening a browser or touching the screen. Use this to
    sanity-check detection against real links before trusting it to click
    anything.

.EXAMPLE
    .\Test-UrlDetection.ps1 -Url "https://claude.ai/chat/11ac785f-c034-4934-9213-b7a33dedc09"

.EXAMPLE
    .\Test-UrlDetection.ps1
    (uses TargetUrl from Config\config.json)
#>

[CmdletBinding()]
param(
    [string]$Url,
    [string]$ConfigPath
)

$ErrorActionPreference = "Stop"

try {
    . (Join-Path $PSScriptRoot "ProviderDetection.ps1")

    if (-not $ConfigPath) { $ConfigPath = Join-Path $PSScriptRoot "..\Config\config.json" }
    $ConfigPath = (Resolve-Path $ConfigPath).Path
    $Config = Get-Content -Raw -Path $ConfigPath | ConvertFrom-Json

    if (-not $Url) { $Url = $Config.TargetUrl }

    $Provider = Find-Provider -Config $Config -Url $Url
    if (-not $Provider) {
        Write-Host ""
        Write-Host "No provider matched '$Url'." -ForegroundColor Yellow
        Write-Host "Configured domains: $(($Config.Providers | ForEach-Object { $_.DomainMatch }) -join ', ')"
        Write-Host ""
        return
    }

    $State  = Get-ChatState -Provider $Provider -Url $Url -DefaultOngoingPattern $Config.DefaultOngoingIdPattern
    $Coords = $Provider.Coordinates.$State

    Write-Host ""
    Write-Host "URL      : $Url"
    Write-Host "Provider : $($Provider.Name)"
    Write-Host "State    : $State"
    Write-Host "Window   : `"$($Provider.BrowserWindowTitleMatch)`""
    Write-Host "PromptBoxClick    -> Enabled=$($Coords.PromptBoxClick.Enabled)  X=$($Coords.PromptBoxClick.X)  Y=$($Coords.PromptBoxClick.Y)"
    Write-Host "AttachButtonClick -> Enabled=$($Coords.AttachButtonClick.Enabled)  X=$($Coords.AttachButtonClick.X)  Y=$($Coords.AttachButtonClick.Y)"
    Write-Host "AttachButtonTabPresses -> $($Coords.AttachButtonTabPresses)"

    if ($Coords.PromptBoxClick.Enabled -and $Coords.PromptBoxClick.X -eq 0 -and $Coords.PromptBoxClick.Y -eq 0) {
        Write-Host ""
        Write-Host "NOTE: PromptBoxClick for $($Provider.Name) / $State is still the 0,0 placeholder - calibrate it before a real run." -ForegroundColor Yellow
    }
    Write-Host ""
}
catch {
    Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red
}
```


═══════════════════════════════════════════════════════════════
FILE: Scripts\Uninstall-ScheduledTask.ps1
SIZE: 0.59 KB | LINES: 23
TYPE: powershell
═══════════════════════════════════════════════════════════════
```powershell
<#
.SYNOPSIS
    Removes the scheduled task created by Install-ScheduledTask.ps1.

.EXAMPLE
    .\Uninstall-ScheduledTask.ps1
    .\Uninstall-ScheduledTask.ps1 -TaskName "MorningDigest"
#>

[CmdletBinding()]
param(
    [string]$TaskName = "AIBrowserAutomation"
)

$ErrorActionPreference = "Stop"

$existing = Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
if ($existing) {
    Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false
    Write-Host "Scheduled task '$TaskName' removed."
} else {
    Write-Host "No scheduled task named '$TaskName' was found."
}
```


═══════════════════════════════════════════════════════════════
FILE: README.md
SIZE: 8.33 KB | LINES: 192
TYPE: markdown
═══════════════════════════════════════════════════════════════
```markdown
# aiBrowserAutomation

Scheduled browser automation: opens a URL, (optionally) attaches files, pastes a prompt from a text file, and submits it — triggered by Windows Task Scheduler at a time you choose.

Everything lives under this one folder and uses only relative/dynamic paths
(`$PSScriptRoot`, `$env:USERNAME`, etc.), so you can copy this whole folder
to another PC at the same path and reinstall the scheduled task there — no
usernames or machine-specific paths are baked into the scripts.

One `config.json` covers every AI site you use. It holds a `Providers`
array — one entry per site (Claude, ChatGPT, Kimi, and anything you add
later) — and each provider carries **two** coordinate sets: one for a brand
new chat, one for an ongoing (existing) chat. At run time the script reads
`TargetUrl`, works out which provider and which of those two states it is,
and automatically uses the matching coordinates. No code changes needed to
add a new site — just a new JSON entry.

## How it works

1. `Install-ScheduledTask.ps1` registers a Windows scheduled task that runs
   `Invoke-AIBrowserAutomation.ps1` at the time you specify.
2. At run time, the script:
   - Looks at `TargetUrl`, matches it to a provider (by domain) and a chat
     state — `New` or `Ongoing` (see "How provider + state detection works"
     below) — and pulls that provider+state's coordinates out of
     `config.json`.
   - Opens `TargetUrl` in your browser.
   - Brings the browser window to the front (matching that provider's
     `BrowserWindowTitleMatch`) and maximizes it, optional.
   - If `UseFileAttachment` is `true`, attaches each file in `FilesToAttach`
     (plus any `<<attach: ...>>` tags found inside `Prompts\prompt.txt`),
     using that provider+state's attach-button coordinates (or Tab count).
   - Pastes the prompt text (via the clipboard) at that provider+state's
     prompt-box coordinates.
   - Presses Enter (or whatever `SubmitKeystroke` you configure) to send it.
   - Logs every step, including what it detected, to `Logs\automation.log`.

## How provider + chat-state detection works

For each URL, detection runs in this order:

1. **Keyword check** — if the URL contains any word from that provider's
   `NewChatKeywords` (default: `["new"]`), it's classified `New` immediately.
2. **ID-pattern check** — otherwise, if the URL matches an "ongoing chat"
   pattern — a long run of hex-ish characters, the kind every conversation
   ID in Claude/ChatGPT/Kimi URLs is made of — it's classified `Ongoing`.
   This uses that provider's own `OngoingPattern` if set, or
   `DefaultOngoingIdPattern` (`[0-9a-fA-F-]{20,}`, i.e. 20+ hex/dash
   characters in a row) otherwise.
3. **Default** — anything matching neither is treated as `New`.

This sorts all six of the original example links correctly:

| URL | Detected | Why |
|---|---|---|
| `claude.ai/new` | New | contains "new" |
| `claude.ai/chat/11ac785f-c034-...` | Ongoing | long ID, no "new" |
| `chatgpt.com/` | New | no "new", no long ID either → default |
| `chatgpt.com/c/6ae81b50-7150-...` | Ongoing | long ID |
| `kimi.ai/?chat_enter_method=new_chat` | New | contains "new" |
| `kimi.ai/chat/1a1a51ea-...?...=history` | Ongoing | long ID |

Run `Test-UrlDetection.ps1 -Url "<any link>"` any time to check how a
specific URL gets classified without opening a browser or touching the
screen.

## First-time setup

**0. Create the folder skeleton** (run once):

```powershell
$root = "C:\.scripts\browserAutomations\aiBrowserAutomation"
New-Item -ItemType Directory -Force -Path "$root\Config","$root\Prompts","$root\Logs","$root\Scripts" | Out-Null
```

Then paste each file into its matching folder.

**1. Edit `Config\config.json`:**
- `TargetUrl` — whatever specific link you want opened this run: a fresh
  "new chat" link, or one specific ongoing conversation's link.
- `PromptFilePath` — defaults to `Prompts/prompt.txt`.
- `UseFileAttachment` / `FilesToAttach` — turn on and list full paths if you
  want files attached on every run (or use `<<attach:...>>` tags in the
  prompt file for one-off attachments instead).
- Leave the `Providers` array as-is for Claude / ChatGPT / Kimi, or add more
  — see "Adding a new AI provider" below.

**2. Edit `Prompts\prompt.txt`** with the prompt you want sent — unchanged
from before (optional `<<attach: C:\full\path\to\file.ext>>` tags still
work the same way).

**3. Calibrate coordinates — once per provider, per state you'll actually use.**

Each provider in `config.json` has a `Coordinates.New` and a
`Coordinates.Ongoing` block. You only need to fill in the ones you'll
actually use — e.g. if you only ever start fresh chats on Claude, you can
leave Claude's `Ongoing` block (and every other provider) at its `0,0`
placeholder.

For each one you do need:

1. Run `Scripts\Get-MousePosition.ps1`.
2. Open that exact kind of link (a real new-chat link, or a real
   ongoing-chat link) for that provider, manually, in your browser.
3. Hover over the prompt box, read off its X/Y, Ctrl+C to stop.
4. Put those values into that provider's matching
   `Coordinates.<New|Ongoing>.PromptBoxClick`, with `"Enabled": true`.
5. Repeat for `AttachButtonClick` too, only if you're using attachments for
   that provider+state.
6. Keep `MaximizeBrowserWindow: true` so the window — and thus the
   coordinates — stay consistent between runs.

The script refuses to run (with a clear error) if `PromptBoxClick` is
`Enabled` but still sitting at the `0,0` placeholder, so you can't
accidentally click the wrong corner of the screen.

**4. Verify detection before you trust it:**

```powershell
powershell -ExecutionPolicy Bypass -File "C:\.scripts\browserAutomations\aiBrowserAutomation\Scripts\Test-UrlDetection.ps1" -Url "https://claude.ai/chat/11ac785f-c034-4934-9213-b7a33dedc09"
```

This prints the provider, state, and coordinates it would use — no browser,
no clicks. Run it once per link style you plan to use.

**5. Test the real thing:**

```powershell
powershell -ExecutionPolicy Bypass -File "C:\.scripts\browserAutomations\aiBrowserAutomation\Scripts\Invoke-AIBrowserAutomation.ps1"
```

Watch it run, check `Logs\automation.log` (it now logs which provider/state
it detected too), and adjust `Wait*Seconds` if it clicks or pastes before
the page has actually finished loading.

**6. Schedule it:**

```powershell
powershell -ExecutionPolicy Bypass -File "C:\.scripts\browserAutomations\aiBrowserAutomation\Scripts\Install-ScheduledTask.ps1" -Time "09:00"
```

Optional: `-Frequency Weekly -DaysOfWeek Monday,Wednesday,Friday`,
`-TaskName "MyOtherAutomation"`, `-ConfigPath "C:\...\config.alt.json"` (for
several differently-timed prompts). Re-run this command any time with new
values to update an already-scheduled task — it overwrites in place, no
reinstall needed.

To remove it later:

```powershell
powershell -ExecutionPolicy Bypass -File "C:\.scripts\browserAutomations\aiBrowserAutomation\Scripts\Uninstall-ScheduledTask.ps1"
```

## Adding a new AI provider

No code changes needed — just a new object in the `Providers` array
(checked in order; the first whose `DomainMatch` is found in the URL wins):

```json
{
  "Name": "Gemini",
  "DomainMatch": "gemini.google.com",
  "BrowserWindowTitleMatch": "Gemini",
  "NewChatKeywords": ["new"],
  "OngoingPattern": "",
  "Coordinates": {
    "New": {
      "PromptBoxClick": { "Enabled": true, "X": 0, "Y": 0 },
      "AttachButtonClick": { "Enabled": false, "X": 0, "Y": 0 },
      "AttachButtonTabPresses": 0
    },
    "Ongoing": {
      "PromptBoxClick": { "Enabled": true, "X": 0, "Y": 0 },
      "AttachButtonClick": { "Enabled": false, "X": 0, "Y": 0 },
      "AttachButtonTabPresses": 0
    }
  }
}
```

- `DomainMatch` — a plain substring of the site's URL, not a regex.
- `NewChatKeywords` — leave `["new"]` unless this site's fresh-chat link
  uses a different word.
- `OngoingPattern` — leave `""` to use the shared default (20+ hex/dash
  characters). Only set your own regex here if this site's conversation IDs
  don't look like that and the default misclassifies them.
- Fill in both `Coordinates` blocks the same way as step 3 above, for
  whichever state(s) you'll actually use.

Then confirm it with `Test-UrlDetection.ps1` before relying on it.

## Attach-tag syntax (inside prompt.txt)
```


╔═══════════════════════════════════════════════════════════════╗
║                        STATISTICS                              ║
╚═══════════════════════════════════════════════════════════════╝
Total Files Processed: 10
Total Lines of Code:   736
Generated by:          Show-Codebase
