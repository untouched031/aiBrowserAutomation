# aiBrowserAutomation

Scheduled browser automation: opens a URL, (optionally) attaches files, pastes a prompt from a text file, and submits it — triggered by Windows Task Scheduler at a time you choose.

Everything lives under this one folder and uses only relative/dynamic paths
(`$PSScriptRoot`, `$env:USERNAME`, etc.), so you can copy this whole folder
to another PC at the same path and reinstall the scheduled task there — no
usernames or machine-specific paths are baked into the scripts.

One `config.json` covers every AI site you use. It holds a `Providers`
array — one entry per site (Claude, ChatGPT, Kimi, and anything you add
later) — and each provider carries **two** coordinate sets: one for a brand
new chat, one for an ongoing (existing) chat. At run time the script reads
`TargetUrl`, works out which provider and which of those two states it is,
and automatically uses the matching coordinates. No code changes needed to
add a new site — just a new JSON entry.

## How it works

1. `Install-ScheduledTask.ps1` registers a Windows scheduled task that runs
   `Invoke-AIBrowserAutomation.ps1` at the time you specify.
2. At run time, the script:
   - Looks at `TargetUrl`, matches it to a provider (by domain) and a chat
     state — `New` or `Ongoing` (see "How provider + state detection works"
     below) — and pulls that provider+state's coordinates out of
     `config.json`.
   - Opens `TargetUrl` in your browser.
   - Brings the browser window to the front (matching that provider's
     `BrowserWindowTitleMatch`) and maximizes it, optional.
   - If `UseFileAttachment` is `true`, attaches each file in `FilesToAttach`
     (plus any `<<attach: ...>>` tags found inside `Prompts\prompt.txt`),
     using that provider+state's attach-button coordinates (or Tab count).
   - Pastes the prompt text (via the clipboard) at that provider+state's
     prompt-box coordinates.
   - Presses Enter (or whatever `SubmitKeystroke` you configure) to send it.
   - Logs every step, including what it detected, to `Logs\automation.log`.

## How provider + chat-state detection works

For each URL, detection runs in this order:

1. **Keyword check** — if the URL contains any word from that provider's
   `NewChatKeywords` (default: `["new"]`), it's classified `New` immediately.
2. **ID-pattern check** — otherwise, if the URL matches an "ongoing chat"
   pattern — a long run of hex-ish characters, the kind every conversation
   ID in Claude/ChatGPT/Kimi URLs is made of — it's classified `Ongoing`.
   This uses that provider's own `OngoingPattern` if set, or
   `DefaultOngoingIdPattern` (`[0-9a-fA-F-]{20,}`, i.e. 20+ hex/dash
   characters in a row) otherwise.
3. **Default** — anything matching neither is treated as `New`.

This sorts all six of the original example links correctly:

| URL | Detected | Why |
|---|---|---|
| `claude.ai/new` | New | contains "new" |
| `claude.ai/chat/11ac785f-c034-...` | Ongoing | long ID, no "new" |
| `chatgpt.com/` | New | no "new", no long ID either → default |
| `chatgpt.com/c/6ae81b50-7150-...` | Ongoing | long ID |
| `kimi.ai/?chat_enter_method=new_chat` | New | contains "new" |
| `kimi.ai/chat/1a1a51ea-...?...=history` | Ongoing | long ID |

Run `Test-UrlDetection.ps1 -Url "<any link>"` any time to check how a
specific URL gets classified without opening a browser or touching the
screen.

## First-time setup

**0. Create the folder skeleton** (run once):

```powershell
$root = "C:\.scripts\browserAutomations\aiBrowserAutomation"
New-Item -ItemType Directory -Force -Path "$root\Config","$root\Prompts","$root\Logs","$root\Scripts" | Out-Null
```

Then paste each file into its matching folder.

**1. Edit `Config\config.json`:**
- `TargetUrl` — whatever specific link you want opened this run: a fresh
  "new chat" link, or one specific ongoing conversation's link.
- `PromptFilePath` — defaults to `Prompts/prompt.txt`.
- `UseFileAttachment` / `FilesToAttach` — turn on and list full paths if you
  want files attached on every run (or use `<<attach:...>>` tags in the
  prompt file for one-off attachments instead).
- Leave the `Providers` array as-is for Claude / ChatGPT / Kimi, or add more
  — see "Adding a new AI provider" below.

**2. Edit `Prompts\prompt.txt`** with the prompt you want sent — unchanged
from before (optional `<<attach: C:\full\path\to\file.ext>>` tags still
work the same way).

**3. Calibrate coordinates — once per provider, per state you'll actually use.**

Each provider in `config.json` has a `Coordinates.New` and a
`Coordinates.Ongoing` block. You only need to fill in the ones you'll
actually use — e.g. if you only ever start fresh chats on Claude, you can
leave Claude's `Ongoing` block (and every other provider) at its `0,0`
placeholder.

For each one you do need:

1. Run `Scripts\Get-MousePosition.ps1`.
2. Open that exact kind of link (a real new-chat link, or a real
   ongoing-chat link) for that provider, manually, in your browser.
3. Hover over the prompt box, read off its X/Y, Ctrl+C to stop.
4. Put those values into that provider's matching
   `Coordinates.<New|Ongoing>.PromptBoxClick`, with `"Enabled": true`.
5. Repeat for `AttachButtonClick` too, only if you're using attachments for
   that provider+state.
6. Keep `MaximizeBrowserWindow: true` so the window — and thus the
   coordinates — stay consistent between runs.

The script refuses to run (with a clear error) if `PromptBoxClick` is
`Enabled` but still sitting at the `0,0` placeholder, so you can't
accidentally click the wrong corner of the screen.

**4. Verify detection before you trust it:**

```powershell
powershell -ExecutionPolicy Bypass -File "C:\.scripts\browserAutomations\aiBrowserAutomation\Scripts\Test-UrlDetection.ps1" -Url "https://claude.ai/chat/11ac785f-c034-4934-9213-b7a33dedc09"
```

This prints the provider, state, and coordinates it would use — no browser,
no clicks. Run it once per link style you plan to use.

**5. Test the real thing:**

```powershell
powershell -ExecutionPolicy Bypass -File "C:\.scripts\browserAutomations\aiBrowserAutomation\Scripts\Invoke-AIBrowserAutomation.ps1"
```

Watch it run, check `Logs\automation.log` (it now logs which provider/state
it detected too), and adjust `Wait*Seconds` if it clicks or pastes before
the page has actually finished loading.

**6. Schedule it:**

```powershell
powershell -ExecutionPolicy Bypass -File "C:\.scripts\browserAutomations\aiBrowserAutomation\Scripts\Install-ScheduledTask.ps1" -Time "09:00"
```

Optional: `-Frequency Weekly -DaysOfWeek Monday,Wednesday,Friday`,
`-TaskName "MyOtherAutomation"`, `-ConfigPath "C:\...\config.alt.json"` (for
several differently-timed prompts). Re-run this command any time with new
values to update an already-scheduled task — it overwrites in place, no
reinstall needed.

To remove it later:

```powershell
powershell -ExecutionPolicy Bypass -File "C:\.scripts\browserAutomations\aiBrowserAutomation\Scripts\Uninstall-ScheduledTask.ps1"
```

## Adding a new AI provider

No code changes needed — just a new object in the `Providers` array
(checked in order; the first whose `DomainMatch` is found in the URL wins):

```json
{
  "Name": "Gemini",
  "DomainMatch": "gemini.google.com",
  "BrowserWindowTitleMatch": "Gemini",
  "NewChatKeywords": ["new"],
  "OngoingPattern": "",
  "Coordinates": {
    "New": {
      "PromptBoxClick": { "Enabled": true, "X": 0, "Y": 0 },
      "AttachButtonClick": { "Enabled": false, "X": 0, "Y": 0 },
      "AttachButtonTabPresses": 0
    },
    "Ongoing": {
      "PromptBoxClick": { "Enabled": true, "X": 0, "Y": 0 },
      "AttachButtonClick": { "Enabled": false, "X": 0, "Y": 0 },
      "AttachButtonTabPresses": 0
    }
  }
}
```

- `DomainMatch` — a plain substring of the site's URL, not a regex.
- `NewChatKeywords` — leave `["new"]` unless this site's fresh-chat link
  uses a different word.
- `OngoingPattern` — leave `""` to use the shared default (20+ hex/dash
  characters). Only set your own regex here if this site's conversation IDs
  don't look like that and the default misclassifies them.
- Fill in both `Coordinates` blocks the same way as step 3 above, for
  whichever state(s) you'll actually use.

Then confirm it with `Test-UrlDetection.ps1` before relying on it.

## Attach-tag syntax (inside prompt.txt)