<#
.SYNOPSIS
    Prints the live screen coordinates of the mouse cursor, so you can find
    the X / Y values for PromptBoxClick / AttachButtonClick in config.json.

.DESCRIPTION
    Run this, then hover the mouse over the chat input box (or the
    attach-file button) in the browser and read the X/Y printed in the
    console. Press Ctrl+C to stop.
#>

Add-Type -AssemblyName System.Windows.Forms

Write-Host "Hover the mouse over the target element. Press Ctrl+C to stop." -ForegroundColor Cyan
while ($true) {
    $pos = [System.Windows.Forms.Cursor]::Position
    Write-Host ("`rX = {0,5}   Y = {1,5}" -f $pos.X, $pos.Y) -NoNewline
    Start-Sleep -Milliseconds 200
}