<#
.SYNOPSIS
    Dry-run helper: given a URL (or no URL, to use config.json's current
    TargetUrl), prints which provider and chat-state it would be detected
    as - without opening a browser or touching the screen. Use this to
    sanity-check detection against real links before trusting it to click
    anything.

.EXAMPLE
    .\Test-UrlDetection.ps1 -Url "https://claude.ai/chat/11ac785f-c034-4934-9213-b7a33dedc09"

.EXAMPLE
    .\Test-UrlDetection.ps1
    (uses TargetUrl from Config\config.json)
#>

[CmdletBinding()]
param(
    [string]$Url,
    [string]$ConfigPath
)

$ErrorActionPreference = "Stop"

try {
    . (Join-Path $PSScriptRoot "ProviderDetection.ps1")

    if (-not $ConfigPath) { $ConfigPath = Join-Path $PSScriptRoot "..\Config\config.json" }
    $ConfigPath = (Resolve-Path $ConfigPath).Path
    $Config = Get-Content -Raw -Path $ConfigPath | ConvertFrom-Json

    if (-not $Url) { $Url = $Config.TargetUrl }

    $Provider = Find-Provider -Config $Config -Url $Url
    if (-not $Provider) {
        Write-Host ""
        Write-Host "No provider matched '$Url'." -ForegroundColor Yellow
        Write-Host "Configured domains: $(($Config.Providers | ForEach-Object { $_.DomainMatch }) -join ', ')"
        Write-Host ""
        return
    }

    $State  = Get-ChatState -Provider $Provider -Url $Url -DefaultOngoingPattern $Config.DefaultOngoingIdPattern
    $Coords = $Provider.Coordinates.$State

    Write-Host ""
    Write-Host "URL      : $Url"
    Write-Host "Provider : $($Provider.Name)"
    Write-Host "State    : $State"
    Write-Host "Window   : `"$($Provider.BrowserWindowTitleMatch)`""
    Write-Host "PromptBoxClick    -> Enabled=$($Coords.PromptBoxClick.Enabled)  X=$($Coords.PromptBoxClick.X)  Y=$($Coords.PromptBoxClick.Y)"
    Write-Host "AttachButtonClick -> Enabled=$($Coords.AttachButtonClick.Enabled)  X=$($Coords.AttachButtonClick.X)  Y=$($Coords.AttachButtonClick.Y)"
    Write-Host "AttachButtonTabPresses -> $($Coords.AttachButtonTabPresses)"

    if ($Coords.PromptBoxClick.Enabled -and $Coords.PromptBoxClick.X -eq 0 -and $Coords.PromptBoxClick.Y -eq 0) {
        Write-Host ""
        Write-Host "NOTE: PromptBoxClick for $($Provider.Name) / $State is still the 0,0 placeholder - calibrate it before a real run." -ForegroundColor Yellow
    }
    Write-Host ""
}
catch {
    Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red
}