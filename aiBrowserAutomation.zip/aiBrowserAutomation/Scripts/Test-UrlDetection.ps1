<#
.SYNOPSIS
    Dry-run helper: given a URL (or a job name, or no argument at all),
    prints which provider and chat-state it would be detected as, without
    opening a browser or touching the screen.

.EXAMPLE
    .\Test-UrlDetection.ps1 -Url "https://claude.ai/chat/11ac785f-c034-4934-9213-b7a33dedc09"

.EXAMPLE
    .\Test-UrlDetection.ps1 -JobName "ClaudeMorningDigest"
    Looks the job up in jobs.json and tests its TargetUrl.
#>

[CmdletBinding()]
param(
    [string]$Url,
    [string]$JobName,
    [string]$ProvidersPath,
    [string]$JobsPath
)

$ErrorActionPreference = "Stop"

try {
    . (Join-Path $PSScriptRoot "ProviderDetection.ps1")

    $ProjectRoot = Split-Path -Parent $PSScriptRoot

    if (-not $ProvidersPath) { $ProvidersPath = Join-Path $PSScriptRoot "..\Config\providers.json" }
    $ProvidersPath = (Resolve-Path $ProvidersPath).Path
    $Config = Get-Content -Raw -Path $ProvidersPath | ConvertFrom-Json

    if ($JobName) {
        . (Join-Path $PSScriptRoot "AutomationRegistry.ps1")
        if (-not $JobsPath) { $JobsPath = Get-JobsPath -ProjectRoot $ProjectRoot }
        $Job = Get-JobByName -JobsPath $JobsPath -TaskName $JobName
        if (-not $Job) { throw "No job named '$JobName' found in $JobsPath." }
        $Url = $Job.TargetUrl
        Write-Host "Job '$JobName' -> $Url" -ForegroundColor DarkGray
    }

    if (-not $Url) { throw "Pass -Url <link> or -JobName <job>." }

    $Provider = Find-Provider -Providers $Config.Providers -Url $Url
    if (-not $Provider) {
        Write-Host ""
        Write-Host "No provider matched '$Url'." -ForegroundColor Yellow
        Write-Host "Configured domains: $(($Config.Providers | ForEach-Object { $_.DomainMatch }) -join ', ')"
        Write-Host ""
        return
    }

    $State  = Get-ChatState -Provider $Provider -Url $Url -DefaultOngoingPattern $Config.DefaultOngoingIdPattern
    $Coords = $Provider.Coordinates.$State

    Write-Host ""
    Write-Host "URL      : $Url"
    Write-Host "Provider : $($Provider.Name)"
    Write-Host "State    : $State"
    Write-Host "Window   : `"$($Provider.BrowserWindowTitleMatch)`""
    Write-Host "PromptBoxClick    -> Enabled=$($Coords.PromptBoxClick.Enabled)  X=$($Coords.PromptBoxClick.X)  Y=$($Coords.PromptBoxClick.Y)"
    Write-Host "AttachButtonClick -> Enabled=$($Coords.AttachButtonClick.Enabled)  X=$($Coords.AttachButtonClick.X)  Y=$($Coords.AttachButtonClick.Y)"
    Write-Host "AttachButtonTabPresses -> $($Coords.AttachButtonTabPresses)"

    if ($Coords.PromptBoxClick.Enabled -and $Coords.PromptBoxClick.X -eq 0 -and $Coords.PromptBoxClick.Y -eq 0) {
        Write-Host ""
        Write-Host "NOTE: PromptBoxClick for $($Provider.Name) / $State is still the 0,0 placeholder - calibrate it before a real run." -ForegroundColor Yellow
    }
    Write-Host ""
}
catch {
    Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red
}