<#
.SYNOPSIS
    Top-level console for aiBrowserAutomation: define Jobs (link + browser
    + prompt file), register Browsers, schedule Jobs, and calibrate
    coordinates - all from one menu.

.DESCRIPTION
    "New Automation" is the guided end-to-end path: give a link a task
    name, pick a browser by name, pick a prompt file, then go straight
    into scheduling it. Everything else here is standalone management for
    editing what already exists. Each menu item just launches the
    relevant focused script in this same Scripts folder - Manage-Jobs.ps1,
    Manage-Browsers.ps1, Manage-ScheduledTask.ps1, and
    Calibrate-Coordinates.ps1 all still work fine run directly, on their
    own, if you'd rather skip this menu entirely.
#>

$ProjectRoot = Split-Path -Parent $PSScriptRoot
. (Join-Path $PSScriptRoot "AutomationRegistry.ps1")

$ErrorActionPreference = "Stop"

$JobsPath = Get-JobsPath -ProjectRoot $ProjectRoot
$BrowsersPath = Get-BrowsersPath -ProjectRoot $ProjectRoot

$ManageJobsScript = Join-Path $PSScriptRoot "Manage-Jobs.ps1"
$ManageBrowsersScript = Join-Path $PSScriptRoot "Manage-Browsers.ps1"
$ManageScheduleScript = Join-Path $PSScriptRoot "Manage-ScheduledTask.ps1"
$CalibrateScript = Join-Path $PSScriptRoot "Calibrate-Coordinates.ps1"
$MigrateScript = Join-Path $PSScriptRoot "Migrate-ToJobs.ps1"

if (-not (Test-Path -LiteralPath $JobsPath)) {
    Write-Host "`n[SETUP NEEDED] $JobsPath doesn't exist yet." -ForegroundColor Yellow
    Write-Host "Run Migrate-ToJobs.ps1 first (it's a one-time step - carries over an existing config.json if you have one, or creates empty starting files if not)." -ForegroundColor Yellow
    $RunNow = Read-Host "`nRun it now? (y/N)"
    if ($RunNow -match '^(y|yes)$') {
        & $MigrateScript
        Read-Host "`nPress Enter to continue to the console"
    } else {
        return
    }
}

function Show-Header {
    Clear-Host
    Write-Host ""
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host "       AI BROWSER AUTOMATION - CONSOLE" -ForegroundColor Cyan
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host ""
}

function Start-NewAutomationWizard {
    Write-Host "`n--- New Automation ---" -ForegroundColor Cyan
    Write-Host "Step 1 of 3: link + task name. Step 2: browser. Step 3: prompt file. Then scheduling." -ForegroundColor DarkGray

    $Job = Add-JobInteractive -JobsPath $JobsPath -BrowsersPath $BrowsersPath -ProjectRoot $ProjectRoot
    if (-not $Job) { return }

    Write-Host "`nJob defined. Now let's schedule it." -ForegroundColor Cyan
    $Reply = Read-Host "Open the scheduling menu now? (Y/n)"
    if ($Reply -notmatch '^(n|no)$') {
        & $ManageScheduleScript
    } else {
        Write-Host "OK - you can schedule '$($Job.TaskName)' anytime from the Scheduling menu." -ForegroundColor Cyan
    }
}

while ($true) {

    Show-Header

    $JobCount = @(Get-AllJobs -JobsPath $JobsPath).Count
    $BrowserCount = @(Get-AllBrowsers -BrowsersPath $BrowsersPath).Count
    Write-Host "  ($JobCount job(s) defined, $BrowserCount browser(s) registered)" -ForegroundColor DarkGray
    Write-Host ""
    Write-Host "  [1] New Automation (link + browser + prompt + schedule)" -ForegroundColor White
    Write-Host "  [2] Manage Jobs"
    Write-Host "  [3] Manage Browsers"
    Write-Host "  [4] Scheduling & Task Management"
    Write-Host "  [5] Calibrate Coordinates"
    Write-Host ""
    Write-Host "  [0] Exit"
    Write-Host ""
    Write-Host "------------------------------------------------------------" -ForegroundColor DarkGray

    $Choice = Read-Host "Select an option"

    if ($Choice -eq "0") {
        Write-Host "`nExiting..." -ForegroundColor Cyan
        break
    }

    try {
        switch ($Choice) {
            "1" { Start-NewAutomationWizard }
            "2" { & $ManageJobsScript }
            "3" { & $ManageBrowsersScript }
            "4" { & $ManageScheduleScript }
            "5" { & $CalibrateScript }
            default {
                Write-Host "`nInvalid selection." -ForegroundColor Red
                Start-Sleep -Seconds 1
            }
        }
    }
    catch {
        Write-Host "`n[ERROR] $($_.Exception.Message)" -ForegroundColor Red
        Read-Host "Press Enter to continue"
    }
}

Write-Host "`nSession closed." -ForegroundColor DarkGray