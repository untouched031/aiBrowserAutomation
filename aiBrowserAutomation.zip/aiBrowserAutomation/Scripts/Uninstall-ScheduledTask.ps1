<#
.SYNOPSIS
    Removes the scheduled task created by Install-ScheduledTask.ps1.

.EXAMPLE
    .\Uninstall-ScheduledTask.ps1
    .\Uninstall-ScheduledTask.ps1 -TaskName "MorningDigest"
#>

[CmdletBinding()]
param(
    [string]$TaskName = "AIBrowserAutomation"
)

$ErrorActionPreference = "Stop"

$existing = Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
if ($existing) {
    Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false
    Write-Host "Scheduled task '$TaskName' removed."
} else {
    Write-Host "No scheduled task named '$TaskName' was found."
}