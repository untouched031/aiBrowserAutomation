<#
.SYNOPSIS
    Interactively calibrates every PromptBoxClick / AttachButtonClick
    coordinate pair in providers.json, one real left-mouse-button click at
    a time.

.DESCRIPTION
    Walks every provider in Config\providers.json, in order, and for each
    of its "New" and "Ongoing" states:
      - Prompts you to click where that state's Prompt Box sits on screen,
        waits for a real left-click anywhere on the screen (not just inside
        the console window - this polls global mouse-button state, so it
        works no matter which window has focus), and writes that click's
        X/Y straight into providers.json, setting Enabled to true.
      - Does the same for the Attach-file button - except that prompt can
        be skipped by pressing S instead of clicking, since not every
        provider+state needs file attachment calibrated.

    Coordinates are shared by every job that targets that provider,
    regardless of which browser or which job runs it - calibrate once per
    provider+state, not once per job.

    Each captured point is saved to disk immediately, so stopping the
    script early (Ctrl+C) never loses whatever was already calibrated -
    only the one prompt you were on when you stopped is left untouched. A
    timestamped backup of providers.json is also taken once, before the
    very first change, and every save is re-read and sanity-checked
    straight after writing it; if anything looks wrong, that save is
    rolled back from the backup automatically and the script stops.

.EXAMPLE
    .\Calibrate-Coordinates.ps1
    Walks every provider, both states (New and Ongoing).

.EXAMPLE
    .\Calibrate-Coordinates.ps1 -ProviderName Claude -StateFilter New
    Only calibrates Claude's "New" state.

.NOTES
    Open the real page for each provider+state BEFORE its prompt comes up -
    in whatever browser window/tab you'll actually use - so the point you
    click is genuinely where that provider's prompt box (or attach button)
    sits. Keep MaximizeBrowserWindow: true in Config\settings.json so that
    spot stays put between calibration and real runs.
#>

[CmdletBinding()]
param(
    [string]$ProvidersPath,
    [string]$ProviderName,
    [ValidateSet("New", "Ongoing")]
    [string]$StateFilter
)

$ErrorActionPreference = "Stop"

Add-Type -AssemblyName System.Windows.Forms

if (-not ([System.Management.Automation.PSTypeName]'AiBrowserAutomationCalibrationInput').Type) {
    Add-Type @"
using System;
using System.Runtime.InteropServices;
public class AiBrowserAutomationCalibrationInput {
    [DllImport("user32.dll")]
    public static extern short GetAsyncKeyState(int vKey);
    public const int VK_LBUTTON = 0x01;
}
"@
}

function Test-LeftButtonDown {
    ([AiBrowserAutomationCalibrationInput]::GetAsyncKeyState([AiBrowserAutomationCalibrationInput]::VK_LBUTTON) -band 0x8000) -ne 0
}

function Wait-ForLeftClick {
    param([switch]$AllowSkip)

    while (Test-LeftButtonDown) { Start-Sleep -Milliseconds 20 }

    while ($true) {
        if ($AllowSkip -and [Console]::KeyAvailable) {
            $key = [Console]::ReadKey($true)
            if ([char]::ToLower($key.KeyChar) -eq 's') { return $null }
        }
        if (Test-LeftButtonDown) {
            $pos = [System.Windows.Forms.Cursor]::Position
            while (Test-LeftButtonDown) { Start-Sleep -Milliseconds 20 }
            return [PSCustomObject]@{ X = $pos.X; Y = $pos.Y }
        }
        Start-Sleep -Milliseconds 20
    }
}

try {
    # ---------- Load providers.json ----------
    if (-not $ProvidersPath) { $ProvidersPath = Join-Path $PSScriptRoot "..\Config\providers.json" }
    $ProvidersPath = (Resolve-Path $ProvidersPath).Path
    $Config = Get-Content -Raw -Path $ProvidersPath | ConvertFrom-Json
    $OriginalProviderCount = @($Config.Providers).Count

    $BackupPath = Join-Path (Split-Path -Parent $ProvidersPath) ("providers.backup-{0}.json" -f (Get-Date -Format "yyyyMMdd-HHmmss"))
    Copy-Item -Path $ProvidersPath -Destination $BackupPath
    Write-Host "Backed up current providers.json -> $BackupPath" -ForegroundColor DarkGray

    function Save-Config {
        $Config | ConvertTo-Json -Depth 10 | Set-Content -Path $ProvidersPath -Encoding UTF8

        try {
            $reloaded = Get-Content -Raw -Path $ProvidersPath | ConvertFrom-Json
        } catch {
            Copy-Item -Path $BackupPath -Destination $ProvidersPath -Force
            throw "providers.json failed to re-parse after saving (restored from $BackupPath). Original error: $($_.Exception.Message)"
        }
        if (@($reloaded.Providers).Count -ne $OriginalProviderCount) {
            Copy-Item -Path $BackupPath -Destination $ProvidersPath -Force
            throw "providers.json's Providers list changed size after saving (restored from $BackupPath). Expected $OriginalProviderCount, got $(@($reloaded.Providers).Count)."
        }
    }

    $providers = @($Config.Providers)
    if ($ProviderName) { $providers = @($providers | Where-Object { $_.Name -eq $ProviderName }) }
    if ($providers.Count -eq 0) {
        throw "No provider found$(if ($ProviderName) { " named '$ProviderName'" }) in $ProvidersPath."
    }
    $states = if ($StateFilter) { @($StateFilter) } else { @("New", "Ongoing") }

    Write-Host ""
    Write-Host "=== Coordinate calibration ===" -ForegroundColor Cyan
    Write-Host "For each prompt: open that provider's real page first, then press the left mouse button at the spot it asks for." -ForegroundColor Cyan
    Write-Host "Ctrl+C stops at any time - everything already captured stays saved." -ForegroundColor Cyan
    Write-Host ""

    foreach ($provider in $providers) {
        foreach ($stateName in $states) {
            $coords = $provider.Coordinates.$stateName
            if (-not $coords) {
                Write-Host "Skipping $($provider.Name) / $stateName - no Coordinates.$stateName block in providers.json." -ForegroundColor Yellow
                continue
            }

            Write-Host "Press LMB at the place of your Prompt Box for $($provider.Name) $stateName." -ForegroundColor White
            $pos = Wait-ForLeftClick
            $coords.PromptBoxClick.X = $pos.X
            $coords.PromptBoxClick.Y = $pos.Y
            $coords.PromptBoxClick.Enabled = $true
            Save-Config
            Write-Host "  -> captured X=$($pos.X)  Y=$($pos.Y)" -ForegroundColor Green

            Write-Host "Press LMB at the place of your Attach button for $($provider.Name) $stateName.  (press S to skip)" -ForegroundColor White
            $pos = Wait-ForLeftClick -AllowSkip
            if ($null -eq $pos) {
                Write-Host "  -> skipped (left as-is)" -ForegroundColor DarkYellow
            } else {
                $coords.AttachButtonClick.X = $pos.X
                $coords.AttachButtonClick.Y = $pos.Y
                $coords.AttachButtonClick.Enabled = $true
                Save-Config
                Write-Host "  -> captured X=$($pos.X)  Y=$($pos.Y)" -ForegroundColor Green
            }

            Write-Host ""
        }
    }

    Write-Host "Calibration complete. Saved to $ProvidersPath" -ForegroundColor Cyan
    Write-Host "Backup of the pre-calibration file: $BackupPath" -ForegroundColor Cyan
    Write-Host "Run Test-UrlDetection.ps1 against a real link for each provider to confirm what it picked up." -ForegroundColor Cyan
}
catch {
    Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red
}