<#
.SYNOPSIS
    Interactive menu for creating, listing, editing, and deleting Jobs -
    the link + browser + prompt-file combinations that Scheduling and
    Invoke-AIBrowserAutomation.ps1 -JobName run against.
#>

$ProjectRoot = Split-Path -Parent $PSScriptRoot
. (Join-Path $PSScriptRoot "AutomationRegistry.ps1")

$ErrorActionPreference = "Stop"

$JobsPath = Get-JobsPath -ProjectRoot $ProjectRoot
$BrowsersPath = Get-BrowsersPath -ProjectRoot $ProjectRoot

function Show-Header {
    Clear-Host
    Write-Host ""
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host "       MANAGE JOBS" -ForegroundColor Cyan
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host ""
}

while ($true) {
    Show-Header
    Show-JobsTable -JobsPath $JobsPath
    Write-Host ""
    Write-Host "  [1] Add a Job"
    Write-Host "  [2] Edit a Job"
    Write-Host "  [3] Delete a Job"
    Write-Host "  [0] Back"
    Write-Host ""
    $Choice = Read-Host "Select an option"

    if ($Choice -eq "0") { break }

    try {
        switch ($Choice) {
            "1" {
                Add-JobInteractive -JobsPath $JobsPath -BrowsersPath $BrowsersPath -ProjectRoot $ProjectRoot | Out-Null
                Read-Host "`nPress Enter to continue"
            }
            "2" {
                $Job = Select-JobFromList -JobsPath $JobsPath -ActionLabel "edit"
                if ($Job) {
                    Edit-JobInteractive -JobsPath $JobsPath -BrowsersPath $BrowsersPath -ProjectRoot $ProjectRoot -Job $Job
                }
                Read-Host "`nPress Enter to continue"
            }
            "3" {
                $Job = Select-JobFromList -JobsPath $JobsPath -ActionLabel "delete"
                if ($Job) {
                    Remove-JobInteractive -JobsPath $JobsPath -Job $Job
                }
                Read-Host "`nPress Enter to continue"
            }
            default {
                Write-Host "`nInvalid selection." -ForegroundColor Red
                Start-Sleep -Seconds 1
            }
        }
    }
    catch {
        Write-Host "`n[ERROR] $($_.Exception.Message)" -ForegroundColor Red
        Read-Host "Press Enter to continue"
    }
}