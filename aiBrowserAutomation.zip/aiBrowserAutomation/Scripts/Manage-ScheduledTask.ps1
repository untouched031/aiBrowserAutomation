<#
.SYNOPSIS
    Interactive console menu for installing, inspecting, and removing the
    aiBrowserAutomation scheduled task - a combined front end for
    Install-ScheduledTask.ps1 and Uninstall-ScheduledTask.ps1.

.DESCRIPTION
    Every menu choice here ends up calling the real, non-interactive
    Install-ScheduledTask.ps1 or Uninstall-ScheduledTask.ps1 in this same
    Scripts folder - this file never duplicates their logic, it only
    collects input and passes it through. Run it with no arguments and
    pick options by number; it loops back to the menu until you choose 0.

.NOTES
    This file must NOT be named Install-ScheduledTask.ps1 or
    Uninstall-ScheduledTask.ps1 - it calls those scripts by that exact
    name, and a file can't call itself.
#>

$Installer   = Join-Path $PSScriptRoot "Install-ScheduledTask.ps1"
$Uninstaller = Join-Path $PSScriptRoot "Uninstall-ScheduledTask.ps1"

$Missing = @($Installer, $Uninstaller) | Where-Object { -not (Test-Path -LiteralPath $_ -PathType Leaf) }
if ($Missing.Count -gt 0) {
    Write-Host "`n[ERROR] Required script(s) not found:" -ForegroundColor Red
    $Missing | ForEach-Object { Write-Host "  $_" -ForegroundColor Yellow }
    return
}

$ErrorActionPreference = "Stop"

# ------------------------------------------------------------
# HELPER FUNCTIONS
# ------------------------------------------------------------

function Show-Header {
    Clear-Host
    Write-Host ""
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host "       AI BROWSER AUTOMATION - TASK MANAGER" -ForegroundColor Cyan
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host ""
}

function Read-TaskTime {
    while ($true) {
        $Time = Read-Host "Enter execution time (HH:mm, 24-hour format)"
        try {
            [void][datetime]::ParseExact($Time, "HH:mm", [Globalization.CultureInfo]::InvariantCulture)
            return $Time
        }
        catch {
            Write-Host "Invalid time. Example: 09:00 or 21:30" -ForegroundColor Red
        }
    }
}

function Read-TaskName {
    $Name = Read-Host "Task name (Enter for default: AIBrowserAutomation)"
    if ([string]::IsNullOrWhiteSpace($Name)) { return "AIBrowserAutomation" }
    return $Name.Trim()
}

function Read-DaysOfWeek {
    param([string]$PromptText = "Days (comma-separated; e.g. Mon,Wed,Fri - use at least 3 letters so Sat/Sun don't clash)")

    $ValidDays = @("Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday")
    $RawInputs = (Read-Host $PromptText).Split(",") | ForEach-Object { $_.Trim() } | Where-Object { $_ -ne "" }

    $Matched   = New-Object System.Collections.Generic.List[string]
    $Unmatched = New-Object System.Collections.Generic.List[string]

    foreach ($RawInput in $RawInputs) {
        $Match = $ValidDays | Where-Object { $_ -like "$RawInput*" } | Select-Object -First 1
        if ($Match) { $Matched.Add($Match) } else { $Unmatched.Add($RawInput) }
    }

    if ($Unmatched.Count -gt 0) {
        Write-Host "Not recognized as a day, ignored: $($Unmatched -join ', ')" -ForegroundColor Yellow
    }

    return @($Matched | Select-Object -Unique)
}

function Get-AutomationTasks {
    @(
        Get-ScheduledTask -ErrorAction SilentlyContinue |
        Where-Object { $_.TaskName -like "*Automation*" -or $_.TaskName -like "*Digest*" } |
        Sort-Object TaskName
    )
}

function Select-AutomationTask {
    param([string]$ActionLabel = "act on")

    $Tasks = @(Get-AutomationTasks)
    if ($Tasks.Count -eq 0) {
        Write-Host "`nNo matching scheduled tasks found." -ForegroundColor Yellow
        return $null
    }

    Write-Host "`nSelect a task to $ActionLabel" -ForegroundColor Cyan
    Write-Host "------------------------------------------------------------"
    for ($i = 0; $i -lt $Tasks.Count; $i++) {
        Write-Host ("[{0}] {1}  |  {2}" -f ($i + 1), $Tasks[$i].TaskName, $Tasks[$i].State)
    }
    Write-Host ""

    $Selection = Read-Host "Task number (0 to cancel)"
    if ($Selection -notmatch '^\d+$') {
        Write-Host "Invalid selection." -ForegroundColor Red
        return $null
    }
    $Index = [int]$Selection
    if ($Index -eq 0) { return $null }
    if ($Index -lt 1 -or $Index -gt $Tasks.Count) {
        Write-Host "Selection out of range." -ForegroundColor Red
        return $null
    }
    return $Tasks[$Index - 1]
}

function Confirm-Action {
    param([string]$Message)
    $Reply = Read-Host "$Message (y/N)"
    return $Reply -match '^(y|yes)$'
}

function Invoke-Installer {
    param(
        [string]$Time,
        [string]$Frequency = "Daily",
        [string[]]$DaysOfWeek = @(),
        [string]$TaskName = "AIBrowserAutomation",
        [string]$ConfigPath = ""
    )

    $Params = @{ Time = $Time; Frequency = $Frequency; TaskName = $TaskName }
    if ($DaysOfWeek.Count -gt 0) { $Params.DaysOfWeek = $DaysOfWeek }
    if (-not [string]::IsNullOrWhiteSpace($ConfigPath)) { $Params.ConfigPath = $ConfigPath }

    Write-Host "`nInstalling..." -ForegroundColor Cyan
    & $Installer @Params
    Write-Host "Done." -ForegroundColor Green
}

function Invoke-Uninstaller {
    param([Parameter(Mandatory)][string]$TaskName)
    Write-Host "`nRemoving '$TaskName'..." -ForegroundColor Cyan
    & $Uninstaller -TaskName $TaskName
}

# ------------------------------------------------------------
# MAIN MENU
# ------------------------------------------------------------

while ($true) {

    Show-Header

    Write-Host "  SCHEDULING" -ForegroundColor Yellow
    Write-Host "  [1]  Install Daily Task"
    Write-Host "  [2]  Install Weekly Task"
    Write-Host "  [3]  Install Weekday Task (Mon-Fri)"
    Write-Host "  [4]  Install Weekend Task (Sat-Sun)"
    Write-Host "  [5]  Install Daily Task with Custom JSON Configuration"
    Write-Host "  [6]  Install Custom Task (Advanced)"
    Write-Host ""
    Write-Host "  TASK MANAGEMENT" -ForegroundColor Yellow
    Write-Host "  [7]  List Automation Tasks"
    Write-Host "  [8]  Inspect a Task"
    Write-Host "  [9]  Run a Task Immediately"
    Write-Host "  [10] Stop a Running Task"
    Write-Host "  [11] Enable a Task"
    Write-Host "  [12] Disable a Task"
    Write-Host ""
    Write-Host "  REMOVAL" -ForegroundColor Yellow
    Write-Host "  [13] Uninstall a Selected Task"
    Write-Host "  [14] Uninstall Default Task (AIBrowserAutomation)"
    Write-Host "  [15] Uninstall All Matching Automation Tasks"
    Write-Host ""
    Write-Host "  UTILITIES" -ForegroundColor Yellow
    Write-Host "  [16] Open Windows Task Scheduler"
    Write-Host "  [17] Open Automation Project Directory"
    Write-Host ""
    Write-Host "  [0] Exit"
    Write-Host ""
    Write-Host "------------------------------------------------------------" -ForegroundColor DarkGray

    $Choice = Read-Host "Select an option"

    if ($Choice -eq "0") {
        Write-Host "`nExiting AI Browser Automation Manager..." -ForegroundColor Cyan
        break
    }

    try {
        switch ($Choice) {

            "1" {
                $Time = Read-TaskTime
                $Name = Read-TaskName
                Invoke-Installer -Time $Time -TaskName $Name
                Read-Host "`nPress Enter to continue"
            }

            "2" {
                $Time = Read-TaskTime
                $Name = Read-TaskName
                $Days = Read-DaysOfWeek
                if ($Days.Count -eq 0) {
                    Write-Host "No valid days recognized - nothing installed." -ForegroundColor Red
                    Read-Host "Press Enter"
                    break
                }
                Invoke-Installer -Time $Time -Frequency Weekly -DaysOfWeek $Days -TaskName $Name
                Read-Host "`nPress Enter to continue"
            }

            "3" {
                $Time = Read-TaskTime
                $Name = Read-TaskName
                Invoke-Installer -Time $Time -Frequency Weekly `
                    -DaysOfWeek @("Monday","Tuesday","Wednesday","Thursday","Friday") `
                    -TaskName $Name
                Read-Host "`nPress Enter to continue"
            }

            "4" {
                $Time = Read-TaskTime
                $Name = Read-TaskName
                Invoke-Installer -Time $Time -Frequency Weekly -DaysOfWeek @("Saturday","Sunday") -TaskName $Name
                Read-Host "`nPress Enter to continue"
            }

            "5" {
                $Time = Read-TaskTime
                $Name = Read-TaskName
                $Config = Read-Host "Full path to JSON configuration"
                if (-not (Test-Path -LiteralPath $Config -PathType Leaf)) {
                    Write-Host "Configuration file not found." -ForegroundColor Red
                    Read-Host "Press Enter"
                    break
                }
                Invoke-Installer -Time $Time -TaskName $Name -ConfigPath $Config
                Read-Host "`nPress Enter to continue"
            }

            "6" {
                $Time = Read-TaskTime
                $Name = Read-TaskName
                $Frequency = Read-Host "Frequency (Daily/Weekly)"
                if ($Frequency -notin @("Daily", "Weekly")) {
                    Write-Host "Invalid frequency." -ForegroundColor Red
                    Read-Host "Press Enter"
                    break
                }
                $Config = Read-Host "Custom JSON path (Enter to skip)"

                $Days = @()
                if ($Frequency -eq "Weekly") {
                    $Days = Read-DaysOfWeek
                    if ($Days.Count -eq 0) {
                        Write-Host "No valid days recognized - nothing installed." -ForegroundColor Red
                        Read-Host "Press Enter"
                        break
                    }
                }

                Invoke-Installer -Time $Time -Frequency $Frequency -DaysOfWeek $Days -TaskName $Name -ConfigPath $Config
                Read-Host "`nPress Enter to continue"
            }

            "7" {
                Show-Header
                $Tasks = @(Get-AutomationTasks)
                if ($Tasks.Count -eq 0) {
                    Write-Host "No matching scheduled tasks found." -ForegroundColor Yellow
                } else {
                    $Tasks | Format-Table TaskName, State, TaskPath -AutoSize
                }
                Read-Host "`nPress Enter to continue"
            }

            "8" {
                $Task = Select-AutomationTask -ActionLabel "inspect"
                if ($null -ne $Task) {
                    Write-Host "`nTASK DETAILS" -ForegroundColor Cyan
                    $Task | Format-List TaskName, State, TaskPath, Author, Description
                    Get-ScheduledTaskInfo -TaskName $Task.TaskName -TaskPath $Task.TaskPath |
                        Format-List LastRunTime, LastTaskResult, NextRunTime, NumberOfMissedRuns
                }
                Read-Host "`nPress Enter to continue"
            }

            "9" {
                $Task = Select-AutomationTask -ActionLabel "run now"
                if ($null -ne $Task) {
                    Start-ScheduledTask -TaskName $Task.TaskName -TaskPath $Task.TaskPath
                    Write-Host "Task start requested." -ForegroundColor Green
                }
                Read-Host "Press Enter"
            }

            "10" {
                $Task = Select-AutomationTask -ActionLabel "stop"
                if ($null -ne $Task) {
                    Stop-ScheduledTask -TaskName $Task.TaskName -TaskPath $Task.TaskPath
                    Write-Host "Task stop requested." -ForegroundColor Green
                }
                Read-Host "Press Enter"
            }

            "11" {
                $Task = Select-AutomationTask -ActionLabel "enable"
                if ($null -ne $Task) {
                    Enable-ScheduledTask -TaskName $Task.TaskName -TaskPath $Task.TaskPath | Out-Null
                    Write-Host "Task enabled." -ForegroundColor Green
                }
                Read-Host "Press Enter"
            }

            "12" {
                $Task = Select-AutomationTask -ActionLabel "disable"
                if ($null -ne $Task) {
                    Disable-ScheduledTask -TaskName $Task.TaskName -TaskPath $Task.TaskPath | Out-Null
                    Write-Host "Task disabled." -ForegroundColor Green
                }
                Read-Host "Press Enter"
            }

            "13" {
                $Task = Select-AutomationTask -ActionLabel "uninstall"
                if ($null -ne $Task) {
                    if (Confirm-Action "Permanently remove '$($Task.TaskName)'?") {
                        Invoke-Uninstaller -TaskName $Task.TaskName
                        Write-Host "Done." -ForegroundColor Green
                    } else {
                        Write-Host "Cancelled." -ForegroundColor Cyan
                    }
                    Read-Host "Press Enter"
                }
            }

            "14" {
                $TaskName = "AIBrowserAutomation"
                $Task = Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
                if ($null -eq $Task) {
                    Write-Host "`nDefault task not found." -ForegroundColor Yellow
                }
                elseif (Confirm-Action "Permanently remove '$TaskName'?") {
                    Invoke-Uninstaller -TaskName $TaskName
                    Write-Host "Done." -ForegroundColor Green
                }
                else {
                    Write-Host "Cancelled." -ForegroundColor Cyan
                }
                Read-Host "Press Enter"
            }

            "15" {
                $Tasks = @(Get-AutomationTasks)
                if ($Tasks.Count -eq 0) {
                    Write-Host "`nNo matching tasks found." -ForegroundColor Yellow
                    Read-Host "Press Enter"
                    break
                }
                Write-Host "`nTASKS SELECTED FOR REMOVAL:" -ForegroundColor Yellow
                $Tasks | Format-Table TaskName, State -AutoSize
                $Confirm = Read-Host "`nType REMOVE ALL to continue"
                if ($Confirm -ceq "REMOVE ALL") {
                    foreach ($Task in $Tasks) { Invoke-Uninstaller -TaskName $Task.TaskName }
                    Write-Host "`nAll matching tasks processed." -ForegroundColor Green
                } else {
                    Write-Host "`nOperation cancelled." -ForegroundColor Cyan
                }
                Read-Host "Press Enter"
            }

            "16" { Start-Process "taskschd.msc" }

            "17" { Start-Process explorer.exe -ArgumentList (Split-Path -Parent $PSScriptRoot) }

            default {
                Write-Host "`nInvalid selection." -ForegroundColor Red
                Start-Sleep -Seconds 1
            }
        }
    }
    catch {
        Write-Host "`n[ERROR] $($_.Exception.Message)" -ForegroundColor Red
        Read-Host "Press Enter to continue"
    }
}

Write-Host "`nSession closed." -ForegroundColor DarkGray