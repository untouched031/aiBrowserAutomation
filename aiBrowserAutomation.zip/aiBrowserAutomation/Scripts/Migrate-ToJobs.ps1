<#
.SYNOPSIS
    One-time migration: splits the old single config.json into the four
    files multi-job/multi-browser support uses - providers.json,
    settings.json, browsers.json, and jobs.json - carrying over your
    existing TargetUrl, calibrated coordinates, and wait-time settings as
    the first Job.

.DESCRIPTION
    Safe to run more than once: if jobs.json already exists, it does
    nothing and tells you so, rather than overwriting anything. Your
    original config.json is left untouched either way, and any scheduled
    task that already calls Invoke-AIBrowserAutomation.ps1 with no
    -JobName (the old default) keeps working exactly as before - this
    migration only adds the new files, it doesn't remove or disable the
    old path.

.EXAMPLE
    .\Migrate-ToJobs.ps1
#>

[CmdletBinding()]
param(
    [string]$ConfigPath
)

$ErrorActionPreference = "Stop"

$ProjectRoot = Split-Path -Parent $PSScriptRoot
$ConfigDir = Join-Path $ProjectRoot "Config"

$ProvidersPath = Join-Path $ConfigDir "providers.json"
$SettingsPath  = Join-Path $ConfigDir "settings.json"
$BrowsersPath  = Join-Path $ConfigDir "browsers.json"
$JobsPath      = Join-Path $ConfigDir "jobs.json"

if (Test-Path -LiteralPath $JobsPath) {
    Write-Host "jobs.json already exists at $JobsPath - nothing to migrate. Delete it first if you really want to re-run this." -ForegroundColor Yellow
    return
}

if (-not $ConfigPath) { $ConfigPath = Join-Path $ConfigDir "config.json" }

if (Test-Path -LiteralPath $ConfigPath) {

    Write-Host "Found existing config.json - migrating its settings and coordinates." -ForegroundColor Cyan
    $Old = Get-Content -Raw -Path $ConfigPath | ConvertFrom-Json

    $ProvidersOut = [PSCustomObject]@{
        DefaultOngoingIdPattern = $Old.DefaultOngoingIdPattern
        Providers               = $Old.Providers
    }
    $ProvidersOut | ConvertTo-Json -Depth 10 | Set-Content -Path $ProvidersPath -Encoding UTF8

    $SettingsOut = [PSCustomObject]@{
        WaitAfterLaunchSeconds      = $Old.WaitAfterLaunchSeconds
        WaitAfterFocusSeconds       = $Old.WaitAfterFocusSeconds
        WaitAfterAttachClickSeconds = $Old.WaitAfterAttachClickSeconds
        WaitAfterFileTypedSeconds   = $Old.WaitAfterFileTypedSeconds
        WaitBeforeSubmitSeconds     = $Old.WaitBeforeSubmitSeconds
        SubmitKeystroke             = $Old.SubmitKeystroke
        MaximizeBrowserWindow       = $Old.MaximizeBrowserWindow
    }
    $SettingsOut | ConvertTo-Json -Depth 10 | Set-Content -Path $SettingsPath -Encoding UTF8

    $BrowsersOut = [PSCustomObject]@{
        Browsers = @([PSCustomObject]@{ Name = "Default"; ExePath = $Old.BrowserExecutable })
    }
    $BrowsersOut | ConvertTo-Json -Depth 10 | Set-Content -Path $BrowsersPath -Encoding UTF8

    $PromptFileName = Split-Path -Leaf $Old.PromptFilePath
    $JobsOut = [PSCustomObject]@{
        Jobs = @([PSCustomObject]@{
            TaskName    = "AIBrowserAutomation"
            TargetUrl   = $Old.TargetUrl
            BrowserName = "Default"
            PromptFile  = $PromptFileName
        })
    }
    $JobsOut | ConvertTo-Json -Depth 10 | Set-Content -Path $JobsPath -Encoding UTF8

    Write-Host ""
    Write-Host "Migration complete:" -ForegroundColor Green
    Write-Host "  providers.json -> your Providers array and coordinates, unchanged"
    Write-Host "  settings.json  -> your Wait*Seconds / SubmitKeystroke / MaximizeBrowserWindow"
    Write-Host "  browsers.json  -> one entry, 'Default', pointing at your BrowserExecutable"
    Write-Host "  jobs.json      -> one job, 'AIBrowserAutomation', using your old TargetUrl and prompt file"
    Write-Host ""
    Write-Host "config.json itself is untouched. Any scheduled task you already installed keeps running exactly as before (legacy mode)." -ForegroundColor Cyan
    Write-Host "Going forward, use Manage-Jobs.ps1 / Manage-Browsers.ps1 / the Scheduling menu for anything new." -ForegroundColor Cyan
}
else {
    Write-Host "No existing config.json found - creating empty starting files for a fresh setup." -ForegroundColor Cyan

    $ProvidersOut = [PSCustomObject]@{
        DefaultOngoingIdPattern = "[0-9a-fA-F-]{20,}"
        Providers               = @()
    }
    $ProvidersOut | ConvertTo-Json -Depth 10 | Set-Content -Path $ProvidersPath -Encoding UTF8

    $SettingsOut = [PSCustomObject]@{
        WaitAfterLaunchSeconds      = 8
        WaitAfterFocusSeconds       = 1
        WaitAfterAttachClickSeconds = 2
        WaitAfterFileTypedSeconds   = 2
        WaitBeforeSubmitSeconds     = 1
        SubmitKeystroke             = "{ENTER}"
        MaximizeBrowserWindow       = $true
    }
    $SettingsOut | ConvertTo-Json -Depth 10 | Set-Content -Path $SettingsPath -Encoding UTF8

    $BrowsersOut = [PSCustomObject]@{ Browsers = @([PSCustomObject]@{ Name = "Default"; ExePath = "" }) }
    $BrowsersOut | ConvertTo-Json -Depth 10 | Set-Content -Path $BrowsersPath -Encoding UTF8

    $JobsOut = [PSCustomObject]@{ Jobs = @() }
    $JobsOut | ConvertTo-Json -Depth 10 | Set-Content -Path $JobsPath -Encoding UTF8

    Write-Host "Created providers.json, settings.json, browsers.json, and an empty jobs.json." -ForegroundColor Green
    Write-Host "Add providers (copy the Claude/ChatGPT/Kimi template from README.md) and run AutomationConsole.ps1 to add your first job." -ForegroundColor Cyan
}