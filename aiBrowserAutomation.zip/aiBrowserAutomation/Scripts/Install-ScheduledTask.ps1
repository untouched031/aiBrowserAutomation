<#
.SYNOPSIS
    Registers (or re-registers) the Windows scheduled task that runs the
    AI browser automation project at a chosen time - daily, weekly, or
    just once at a specific date and time.

.EXAMPLE
    .\Install-ScheduledTask.ps1 -Time "09:00"

.EXAMPLE
    .\Install-ScheduledTask.ps1 -Time "18:30" -Frequency Weekly -DaysOfWeek Monday,Wednesday,Friday

.EXAMPLE
    .\Install-ScheduledTask.ps1 -Time "09:00" -Frequency Once -Date "2026-12-25"

.EXAMPLE
    .\Install-ScheduledTask.ps1 -Time "07:00" -TaskName "MorningDigest" -ConfigPath "C:\.scripts\browserAutomations\aiBrowserAutomation\Config\config.morning.json"
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidatePattern('^\d{1,2}:\d{2}$')]
    [string]$Time,

    [ValidateSet("Daily", "Weekly", "Once")]
    [string]$Frequency = "Daily",

    [ValidateSet("Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday")]
    [string[]]$DaysOfWeek = @("Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"),

    [string]$TaskName = "AIBrowserAutomation",

    [string]$ConfigPath,

    # Required (format yyyy-MM-dd) only when -Frequency is "Once".
    [string]$Date
)

$ErrorActionPreference = "Stop"

$ProjectRoot = Split-Path -Parent $PSScriptRoot
$MainScript  = Join-Path $PSScriptRoot "Invoke-AIBrowserAutomation.ps1"

if (-not (Test-Path $MainScript)) {
    throw "Could not find main script at: $MainScript"
}

$LogsDir = Join-Path $ProjectRoot "Logs"
if (-not (Test-Path $LogsDir)) { New-Item -ItemType Directory -Path $LogsDir -Force | Out-Null }

$PowerShellExe = (Get-Command powershell.exe).Source

$ArgList = "-NoProfile -ExecutionPolicy Bypass -WindowStyle Normal -File `"$MainScript`""
if ($ConfigPath) {
    $ArgList += " -ConfigPath `"$ConfigPath`""
}

$Action = New-ScheduledTaskAction -Execute $PowerShellExe -Argument $ArgList -WorkingDirectory $ProjectRoot

$NormalizedTime = $Time.PadLeft(5, '0')
$ParsedTime = [DateTime]::ParseExact($NormalizedTime, "HH:mm", [System.Globalization.CultureInfo]::InvariantCulture)

$DescriptionSuffix = ""
$FireAt = $null

if ($Frequency -eq "Once") {
    if ([string]::IsNullOrWhiteSpace($Date)) {
        throw "-Date is required when -Frequency is 'Once' (format: yyyy-MM-dd, e.g. 2026-12-25)."
    }
    try {
        $ParsedDate = [DateTime]::ParseExact($Date, "yyyy-MM-dd", [System.Globalization.CultureInfo]::InvariantCulture)
    } catch {
        throw "-Date '$Date' is not a valid date. Use yyyy-MM-dd, e.g. 2026-12-25."
    }

    $FireAt = $ParsedDate.Date.Add($ParsedTime.TimeOfDay)
    if ($FireAt -le (Get-Date)) {
        throw "That date and time ($($FireAt.ToString('yyyy-MM-dd HH:mm'))) is already in the past. Pick a time in the future."
    }

    $Trigger = New-ScheduledTaskTrigger -Once -At $FireAt
    $DescriptionSuffix = " (one-time run)"
}
elseif ($Frequency -eq "Daily") {
    $Trigger = New-ScheduledTaskTrigger -Daily -At $ParsedTime
}
else {
    $Trigger = New-ScheduledTaskTrigger -Weekly -DaysOfWeek $DaysOfWeek -At $ParsedTime
}

$Principal = New-ScheduledTaskPrincipal -UserId "$env:USERDOMAIN\$env:USERNAME" -LogonType Interactive -RunLevel Limited

$Settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable -ExecutionTimeLimit (New-TimeSpan -Hours 1)

Register-ScheduledTask -TaskName $TaskName -Action $Action -Trigger $Trigger -Principal $Principal -Settings $Settings -Description "aiBrowserAutomation: opens a browser, pastes a prompt, optionally attaches files, and submits it.$DescriptionSuffix" -Force | Out-Null

if ($Frequency -eq "Once") {
    Write-Host "Scheduled task '$TaskName' installed: runs once on $($FireAt.ToString('yyyy-MM-dd')) at $($FireAt.ToString('HH:mm')), running as $env:USERNAME (requires an unlocked, logged-in session). It stays listed after it runs until you remove it (menu option 14, or Uninstall-ScheduledTask.ps1 directly)."
} else {
    Write-Host "Scheduled task '$TaskName' installed: $Frequency at $Time, running as $env:USERNAME (requires an unlocked, logged-in session)."
}