<#
.SYNOPSIS
    Registers (or re-registers) the Windows scheduled task that runs the
    AI browser automation project at a chosen time.

.EXAMPLE
    .\Install-ScheduledTask.ps1 -Time "09:00"

.EXAMPLE
    .\Install-ScheduledTask.ps1 -Time "18:30" -Frequency Weekly -DaysOfWeek Monday,Wednesday,Friday

.EXAMPLE
    .\Install-ScheduledTask.ps1 -Time "07:00" -TaskName "MorningDigest" -ConfigPath "C:\.scripts\browserAutomations\aiBrowserAutomation\Config\config.morning.json"
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidatePattern('^\d{1,2}:\d{2}$')]
    [string]$Time,

    [ValidateSet("Daily", "Weekly")]
    [string]$Frequency = "Daily",

    [ValidateSet("Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday")]
    [string[]]$DaysOfWeek = @("Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"),

    [string]$TaskName = "AIBrowserAutomation",

    [string]$ConfigPath
)

$ErrorActionPreference = "Stop"

$ProjectRoot = Split-Path -Parent $PSScriptRoot
$MainScript  = Join-Path $PSScriptRoot "Invoke-AIBrowserAutomation.ps1"

if (-not (Test-Path $MainScript)) {
    throw "Could not find main script at: $MainScript"
}

$LogsDir = Join-Path $ProjectRoot "Logs"
if (-not (Test-Path $LogsDir)) { New-Item -ItemType Directory -Path $LogsDir -Force | Out-Null }

$PowerShellExe = (Get-Command powershell.exe).Source

$ArgList = "-NoProfile -ExecutionPolicy Bypass -WindowStyle Normal -File `"$MainScript`""
if ($ConfigPath) {
    $ArgList += " -ConfigPath `"$ConfigPath`""
}

$Action = New-ScheduledTaskAction -Execute $PowerShellExe -Argument $ArgList -WorkingDirectory $ProjectRoot

$NormalizedTime = $Time.PadLeft(5, '0')
$ParsedTime = [DateTime]::ParseExact($NormalizedTime, "HH:mm", [System.Globalization.CultureInfo]::InvariantCulture)

if ($Frequency -eq "Daily") {
    $Trigger = New-ScheduledTaskTrigger -Daily -At $ParsedTime
} else {
    $Trigger = New-ScheduledTaskTrigger -Weekly -DaysOfWeek $DaysOfWeek -At $ParsedTime
}

$Principal = New-ScheduledTaskPrincipal -UserId "$env:USERDOMAIN\$env:USERNAME" -LogonType Interactive -RunLevel Limited

$Settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable -ExecutionTimeLimit (New-TimeSpan -Hours 1)

Register-ScheduledTask -TaskName $TaskName -Action $Action -Trigger $Trigger -Principal $Principal -Settings $Settings -Description "aiBrowserAutomation: opens a browser, pastes a prompt, optionally attaches files, and submits it." -Force | Out-Null

Write-Host "Scheduled task '$TaskName' installed: $Frequency at $Time, running as $env:USERNAME (requires an unlocked, logged-in session)."