<#
.SYNOPSIS
    Opens a target URL in the browser, detects which AI provider and which
    chat state (new vs ongoing) that URL belongs to, optionally attaches
    files, pastes a prompt loaded from a text file, and submits it.

.DESCRIPTION
    Two ways to tell this script what to run:

    -JobName <name>  (recommended)
        Looks the name up in Config\jobs.json, which supplies the link
        (TargetUrl), which registered browser to use (BrowserName, looked
        up in Config\browsers.json), and which file in Prompts\ to send
        (PromptFile). Provider/coordinate detection and the Wait*Seconds /
        SubmitKeystroke settings come from Config\providers.json and
        Config\settings.json, shared by every job. Editing a job later
        (link, browser, or prompt file) takes effect on its next run
        automatically - nothing is baked in at schedule-install time.

    -ConfigPath <path>  (legacy, single-job mode)
        The original all-in-one config.json format from before multi-job
        support: TargetUrl, BrowserExecutable, PromptFilePath and the
        Providers array all in one file. Kept working as-is so any
        scheduled task created before this upgrade keeps running
        unchanged. Defaults to Config\config.json if neither -JobName nor
        -ConfigPath is given.

    Every path is resolved relative to this script's own location
    ($PSScriptRoot), so the whole project folder can be copied to any PC
    and just works, with no usernames or machine-specific paths hardcoded
    anywhere.

    Attaching a file (per provider+state, via providers.json's
    "AttachMethod"):
      - "Dialog" (default): clicks the site's own attach button, which
        opens Windows' native Open-File dialog, and pastes the file's path
        into that dialog's filename field. Works on any site with a
        standard file-upload button, since it drives the OS dialog every
        site uses the same way.
      - "ClipboardPaste" (optional, needs testing per site): skips the
        attach button and OS dialog entirely. Puts the file itself onto
        the clipboard in the same format Explorer's Ctrl+C produces (via
        .NET's Clipboard.SetFileDropList - no Explorer window is actually
        driven), focuses the prompt box, and pastes directly there with
        Ctrl+V, the same gesture as pasting a screenshot. Whether this
        actually attaches the file depends on whether that site's own
        paste handling supports arbitrary files, not just images - this
        is not guaranteed to work and should be tried per provider+state
        before being relied on.

.NOTES
    - This drives the real screen (clipboard + simulated keystrokes/clicks),
      so the PC must be logged in and unlocked when it runs.
    - UI automation is timing- and layout-dependent. Calibrate the
      Wait*Seconds values (Config\settings.json) and each provider's
      coordinates (Config\providers.json, via Calibrate-Coordinates.ps1)
      for your target sites.
#>

[CmdletBinding()]
param(
    [string]$JobName,
    [string]$ConfigPath,
    [string]$JobsPath,
    [string]$BrowsersPath,
    [string]$ProvidersPath,
    [string]$SettingsPath
)

$ErrorActionPreference = "Stop"

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

Add-Type @"
using System;
using System.Runtime.InteropServices;
public class AiBrowserAutomationMouse {
    [DllImport("user32.dll")]
    public static extern void mouse_event(uint dwFlags, uint dx, uint dy, uint dwData, UIntPtr dwExtraInfo);
    public const uint LEFTDOWN = 0x0002;
    public const uint LEFTUP   = 0x0004;
}
"@

# ---------- Paths & logging ----------
$ProjectRoot = Split-Path -Parent $PSScriptRoot
$LogDir = Join-Path $ProjectRoot "Logs"
if (-not (Test-Path $LogDir)) { New-Item -ItemType Directory -Path $LogDir -Force | Out-Null }

# A job's TaskName becomes its own log file; legacy/no-job runs share one
# log, same as before this upgrade.
$LogFile = $null

function Write-Log {
    param([string]$Message)
    $line = "[{0}] {1}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $Message
    Add-Content -Path $LogFile -Value $line
    Write-Host $line
}

function Resolve-ProjectPath {
    param([string]$PathValue)
    if ([string]::IsNullOrWhiteSpace($PathValue)) { return $null }
    if ([System.IO.Path]::IsPathRooted($PathValue)) { return $PathValue }
    return (Join-Path $ProjectRoot $PathValue)
}

function Send-KeysWait {
    param([string]$Keys, [int]$DelayMs = 150)
    Start-Sleep -Milliseconds $DelayMs
    [System.Windows.Forms.SendKeys]::SendWait($Keys)
}

function Invoke-MouseClick {
    param([int]$X, [int]$Y)
    [System.Windows.Forms.Cursor]::Position = New-Object System.Drawing.Point($X, $Y)
    Start-Sleep -Milliseconds 200
    [AiBrowserAutomationMouse]::mouse_event([AiBrowserAutomationMouse]::LEFTDOWN, 0, 0, 0, [UIntPtr]::Zero)
    Start-Sleep -Milliseconds 80
    [AiBrowserAutomationMouse]::mouse_event([AiBrowserAutomationMouse]::LEFTUP, 0, 0, 0, [UIntPtr]::Zero)
    Start-Sleep -Milliseconds 200
}

function Show-BrowserWindow {
    param([string]$TitleMatch, [int]$TimeoutSeconds = 15)
    if ([string]::IsNullOrWhiteSpace($TitleMatch)) { return $false }
    $shell = New-Object -ComObject WScript.Shell
    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    while ($sw.Elapsed.TotalSeconds -lt $TimeoutSeconds) {
        if ($shell.AppActivate($TitleMatch)) {
            Write-Log "Activated a window matching '$TitleMatch'."
            return $true
        }
        Start-Sleep -Milliseconds 500
    }
    Write-Log "WARNING: no window matching '$TitleMatch' found within $TimeoutSeconds s."
    return $false
}

function Maximize-BrowserWindow {
    Send-KeysWait -Keys "% " -DelayMs 250
    Send-KeysWait -Keys "x" -DelayMs 250
}

function Get-PromptPayload {
    param([string]$PromptFile)
    if (-not (Test-Path $PromptFile)) {
        throw "Prompt file not found: $PromptFile"
    }
    $raw = Get-Content -Raw -Path $PromptFile
    $pattern = '<<attach:\s*(.+?)\s*>>'
    $regexMatches = [System.Text.RegularExpressions.Regex]::Matches($raw, $pattern)
    $attachments = @()
    foreach ($m in $regexMatches) { $attachments += $m.Groups[1].Value.Trim() }
    $clean = ($raw -replace $pattern, '').Trim()
    [PSCustomObject]@{
        Text        = $clean
        Attachments = $attachments
    }
}

function Get-SanitizedFileName {
    param([string]$Name)
    $invalid = [System.IO.Path]::GetInvalidFileNameChars() -join ''
    $pattern = "[{0}]" -f [System.Text.RegularExpressions.Regex]::Escape($invalid)
    return ([System.Text.RegularExpressions.Regex]::Replace($Name, $pattern, "_"))
}

function Send-FileAttachment {
    param(
        [string]$FilePath,
        $Coords,
        [string]$WindowTitleMatch,
        $Settings
    )

    $AttachMethod = $Coords.AttachMethod
    if ([string]::IsNullOrWhiteSpace($AttachMethod)) { $AttachMethod = "Dialog" }

    if ($AttachMethod -eq "ClipboardPaste") {
        # Puts the file itself on the clipboard, the same format Explorer's
        # Ctrl+C produces - no Explorer window is opened or driven. Then
        # pastes directly into the prompt box, like pasting a screenshot.
        if ($Coords.PromptBoxClick.Enabled) {
            Invoke-MouseClick -X $Coords.PromptBoxClick.X -Y $Coords.PromptBoxClick.Y
        } else {
            Show-BrowserWindow -TitleMatch $WindowTitleMatch | Out-Null
        }
        $FileList = New-Object System.Collections.Specialized.StringCollection
        $FileList.Add($FilePath) | Out-Null
        [System.Windows.Forms.Clipboard]::SetFileDropList($FileList)
        Start-Sleep -Milliseconds 300
        Send-KeysWait -Keys "^v" -DelayMs 150
        Start-Sleep -Seconds $Settings.WaitAfterAttachClickSeconds
    }
    else {
        # Default: click (or Tab to) the site's own attach button, which
        # opens the OS's native Open-File dialog, then paste the path into
        # that dialog's filename field - works the same on any site.
        if ($Coords.AttachButtonClick.Enabled) {
            Invoke-MouseClick -X $Coords.AttachButtonClick.X -Y $Coords.AttachButtonClick.Y
        } else {
            for ($i = 0; $i -lt [int]$Coords.AttachButtonTabPresses; $i++) {
                Send-KeysWait -Keys "{TAB}" -DelayMs 150
            }
            Send-KeysWait -Keys "{ENTER}" -DelayMs 300
        }
        Start-Sleep -Seconds $Settings.WaitAfterAttachClickSeconds

        Set-Clipboard -Value $FilePath
        Send-KeysWait -Keys "^a" -DelayMs 150
        Send-KeysWait -Keys "^v" -DelayMs 150
        Start-Sleep -Milliseconds 500
        Send-KeysWait -Keys "{ENTER}" -DelayMs 150

        Start-Sleep -Seconds $Settings.WaitAfterFileTypedSeconds
        Show-BrowserWindow -TitleMatch $WindowTitleMatch | Out-Null
    }
}

try {
    # ---------- Resolve run mode: new -JobName, or legacy -ConfigPath ----------
    $UsingJob = -not [string]::IsNullOrWhiteSpace($JobName)

    if ($UsingJob) {
        $LogFile = Join-Path $LogDir ((Get-SanitizedFileName $JobName) + ".log")
    } else {
        $LogFile = Join-Path $LogDir "automation.log"
    }
    Write-Log "===== Run started ====="

    if ($UsingJob) {
        . (Join-Path $PSScriptRoot "AutomationRegistry.ps1")
        . (Join-Path $PSScriptRoot "ProviderDetection.ps1")

        if (-not $JobsPath)      { $JobsPath      = Get-JobsPath -ProjectRoot $ProjectRoot }
        if (-not $BrowsersPath)  { $BrowsersPath   = Get-BrowsersPath -ProjectRoot $ProjectRoot }
        if (-not $ProvidersPath) { $ProvidersPath  = Join-Path $ProjectRoot "Config\providers.json" }
        if (-not $SettingsPath)  { $SettingsPath   = Join-Path $ProjectRoot "Config\settings.json" }

        $Job = Get-JobByName -JobsPath $JobsPath -TaskName $JobName
        if (-not $Job) {
            throw "No job named '$JobName' found in $JobsPath. Run Manage-Jobs.ps1 to create it."
        }

        $Browser = Get-BrowserByName -BrowsersPath $BrowsersPath -Name $Job.BrowserName
        if (-not $Browser) {
            throw "Job '$JobName' references browser '$($Job.BrowserName)', which is not registered in $BrowsersPath. Run Manage-Browsers.ps1 to add it, or edit the job."
        }

        if (-not (Test-Path $ProvidersPath)) {
            throw "Providers file not found: $ProvidersPath. Run Migrate-ToJobs.ps1 (or create it from the template in README.md)."
        }
        $ProvidersData = Get-Content -Raw -Path $ProvidersPath | ConvertFrom-Json

        if (-not (Test-Path $SettingsPath)) {
            throw "Settings file not found: $SettingsPath. Run Migrate-ToJobs.ps1 (or create it from the template in README.md)."
        }
        $Settings = Get-Content -Raw -Path $SettingsPath | ConvertFrom-Json

        $TargetUrl         = $Job.TargetUrl
        $BrowserExecutable = $Browser.ExePath
        $PromptFilePath    = Join-Path $ProjectRoot "Prompts\$($Job.PromptFile)"

        Write-Log "Job '$JobName' -> $TargetUrl (browser: $($Browser.Name), prompt: $($Job.PromptFile))"
    }
    else {
        if (-not $ConfigPath) { $ConfigPath = Join-Path $PSScriptRoot "..\Config\config.json" }
        $ConfigPath = (Resolve-Path $ConfigPath).Path
        $Config = Get-Content -Raw -Path $ConfigPath | ConvertFrom-Json

        $ProvidersData = $Config
        $Settings      = $Config

        $TargetUrl         = $Config.TargetUrl
        $BrowserExecutable = $Config.BrowserExecutable
        $PromptFilePath    = Resolve-ProjectPath $Config.PromptFilePath

        Write-Log "Legacy config mode -> $ConfigPath"
    }

    . (Join-Path $PSScriptRoot "ProviderDetection.ps1")

    $Provider = Find-Provider -Providers $ProvidersData.Providers -Url $TargetUrl
    if (-not $Provider) {
        throw "No entry under 'Providers' matches the domain of '$TargetUrl'. Add a Providers entry with a matching 'DomainMatch'."
    }
    $State = Get-ChatState -Provider $Provider -Url $TargetUrl -DefaultOngoingPattern $ProvidersData.DefaultOngoingIdPattern
    $Coords = $Provider.Coordinates.$State
    if (-not $Coords) {
        throw "Provider '$($Provider.Name)' has no Coordinates.$State block."
    }
    $WindowTitleMatch = $Provider.BrowserWindowTitleMatch
    Write-Log "TargetUrl matched provider '$($Provider.Name)', detected as '$State' chat."

    function Test-Calibrated {
        param($Click, [string]$Label)
        if ($Click.Enabled -and $Click.X -eq 0 -and $Click.Y -eq 0) {
            throw "$Label is enabled but still at the placeholder X=0, Y=0. Run Scripts\Calibrate-Coordinates.ps1 first."
        }
    }
    Test-Calibrated -Click $Coords.PromptBoxClick -Label "$($Provider.Name) / $State / PromptBoxClick"

    $payload = Get-PromptPayload -PromptFile $PromptFilePath
    $promptText = $payload.Text

    $allAttachments = @()
    if (-not $UsingJob -and $Config.FilesToAttach) { $allAttachments += @($Config.FilesToAttach) }
    if ($payload.Attachments) { $allAttachments += @($payload.Attachments) }

    if ([string]::IsNullOrWhiteSpace($promptText)) {
        throw "Prompt file is empty (after removing <<attach:...>> tags): $PromptFilePath"
    }
    Write-Log "Prompt loaded ($($promptText.Length) chars). Attachments queued: $($allAttachments.Count)."

    $AttachMethodInUse = $Coords.AttachMethod
    if ([string]::IsNullOrWhiteSpace($AttachMethodInUse)) { $AttachMethodInUse = "Dialog" }
    if ($allAttachments.Count -gt 0 -and $AttachMethodInUse -eq "Dialog") {
        Test-Calibrated -Click $Coords.AttachButtonClick -Label "$($Provider.Name) / $State / AttachButtonClick"
    }

    # 1) Open the link
    if ([string]::IsNullOrWhiteSpace($BrowserExecutable)) {
        Write-Log "Launching default browser -> $TargetUrl"
        Start-Process -FilePath $TargetUrl
    } else {
        Write-Log "Launching '$BrowserExecutable' -> $TargetUrl"
        Start-Process -FilePath $BrowserExecutable -ArgumentList $TargetUrl
    }
    Start-Sleep -Seconds $Settings.WaitAfterLaunchSeconds

    # 2) Bring it to the front (and optionally maximize, for reliable click coordinates)
    Show-BrowserWindow -TitleMatch $WindowTitleMatch | Out-Null
    if ($Settings.MaximizeBrowserWindow) { Maximize-BrowserWindow }
    Start-Sleep -Seconds $Settings.WaitAfterFocusSeconds

    # 3) Attachments first (most chat UIs keep a file attached while you then type the message)
    if ($allAttachments.Count -gt 0) {
        foreach ($filePath in $allAttachments) {
            if (-not (Test-Path $filePath)) {
                Write-Log "WARNING: attachment not found, skipping -> $filePath"
                continue
            }
            Write-Log "Attaching ($AttachMethodInUse) -> $filePath"
            Send-FileAttachment -FilePath $filePath -Coords $Coords -WindowTitleMatch $WindowTitleMatch -Settings $Settings
        }
        Start-Sleep -Seconds 1
    }

    # 4) Focus the prompt box
    if ($Coords.PromptBoxClick.Enabled) {
        Invoke-MouseClick -X $Coords.PromptBoxClick.X -Y $Coords.PromptBoxClick.Y
    } else {
        Show-BrowserWindow -TitleMatch $WindowTitleMatch | Out-Null
    }

    # 5) Paste the prompt via the clipboard
    Set-Clipboard -Value $promptText
    Start-Sleep -Milliseconds 400
    Send-KeysWait -Keys "^v" -DelayMs 150
    Start-Sleep -Seconds $Settings.WaitBeforeSubmitSeconds

    # 6) Submit
    Send-KeysWait -Keys $Settings.SubmitKeystroke -DelayMs 150

    Write-Log "Prompt submitted."
    Write-Log "===== Run finished OK ====="
}
catch {
    if ($LogFile) { Write-Log "ERROR: $($_.Exception.Message)" }
    throw
}