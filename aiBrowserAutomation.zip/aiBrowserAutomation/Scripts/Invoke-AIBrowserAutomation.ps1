<#
.SYNOPSIS
    Opens a target URL in the browser, detects which AI provider and which
    chat state (new vs ongoing) that URL belongs to, optionally attaches
    files, pastes a prompt loaded from a text file, and submits it.

.DESCRIPTION
    Meant to be triggered by a Windows scheduled task (see
    Install-ScheduledTask.ps1). Every path is resolved relative to this
    script's own location ($PSScriptRoot), so the whole project folder can
    be copied to any PC and just works, with no usernames or machine-specific
    paths hardcoded anywhere.

    Config\config.json holds a "Providers" array: one entry per AI site
    (Claude, ChatGPT, Kimi, ...), each with its own window-title match and
    two coordinate sets - one for a brand-new chat, one for an ongoing
    (existing) chat. At run time this script looks at TargetUrl, works out
    which provider and which state it is (see ProviderDetection.ps1), and
    uses that provider+state's coordinates automatically. See README.md for
    how detection works and how to add a new provider.

.NOTES
    - This drives the real screen (clipboard + simulated keystrokes/clicks),
      so the PC must be logged in and unlocked when it runs.
    - UI automation is timing- and layout-dependent. Calibrate the
      Wait*Seconds values and each provider's coordinates in
      Config\config.json - see README.md.
#>

[CmdletBinding()]
param(
    [string]$ConfigPath
)

$ErrorActionPreference = "Stop"

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

Add-Type @"
using System;
using System.Runtime.InteropServices;
public class AiBrowserAutomationMouse {
    [DllImport("user32.dll")]
    public static extern void mouse_event(uint dwFlags, uint dx, uint dy, uint dwData, UIntPtr dwExtraInfo);
    public const uint LEFTDOWN = 0x0002;
    public const uint LEFTUP   = 0x0004;
}
"@

# ---------- Paths & logging (set up first, so even an early error gets logged) ----------
$ProjectRoot = Split-Path -Parent $PSScriptRoot
$LogDir  = Join-Path $ProjectRoot "Logs"
$LogFile = Join-Path $LogDir "automation.log"
if (-not (Test-Path $LogDir)) { New-Item -ItemType Directory -Path $LogDir -Force | Out-Null }

function Write-Log {
    param([string]$Message)
    $line = "[{0}] {1}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $Message
    Add-Content -Path $LogFile -Value $line
    Write-Host $line
}

function Resolve-ProjectPath {
    param([string]$PathValue)
    if ([string]::IsNullOrWhiteSpace($PathValue)) { return $null }
    if ([System.IO.Path]::IsPathRooted($PathValue)) { return $PathValue }
    return (Join-Path $ProjectRoot $PathValue)
}

function Send-KeysWait {
    param([string]$Keys, [int]$DelayMs = 150)
    Start-Sleep -Milliseconds $DelayMs
    [System.Windows.Forms.SendKeys]::SendWait($Keys)
}

function Invoke-MouseClick {
    param([int]$X, [int]$Y)
    [System.Windows.Forms.Cursor]::Position = New-Object System.Drawing.Point($X, $Y)
    Start-Sleep -Milliseconds 200
    [AiBrowserAutomationMouse]::mouse_event([AiBrowserAutomationMouse]::LEFTDOWN, 0, 0, 0, [UIntPtr]::Zero)
    Start-Sleep -Milliseconds 80
    [AiBrowserAutomationMouse]::mouse_event([AiBrowserAutomationMouse]::LEFTUP, 0, 0, 0, [UIntPtr]::Zero)
    Start-Sleep -Milliseconds 200
}

function Show-BrowserWindow {
    param([string]$TitleMatch, [int]$TimeoutSeconds = 15)
    if ([string]::IsNullOrWhiteSpace($TitleMatch)) { return $false }
    $shell = New-Object -ComObject WScript.Shell
    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    while ($sw.Elapsed.TotalSeconds -lt $TimeoutSeconds) {
        if ($shell.AppActivate($TitleMatch)) {
            Write-Log "Activated a window matching '$TitleMatch'."
            return $true
        }
        Start-Sleep -Milliseconds 500
    }
    Write-Log "WARNING: no window matching '$TitleMatch' found within $TimeoutSeconds s."
    return $false
}

function Maximize-BrowserWindow {
    # Alt+Space opens the active window's system menu; "x" is the Maximize mnemonic.
    Send-KeysWait -Keys "% " -DelayMs 250
    Send-KeysWait -Keys "x" -DelayMs 250
}

function Get-PromptPayload {
    param([string]$PromptFile)
    if (-not (Test-Path $PromptFile)) {
        throw "Prompt file not found: $PromptFile"
    }
    $raw = Get-Content -Raw -Path $PromptFile
    $pattern = '<<attach:\s*(.+?)\s*>>'
    $regexMatches = [System.Text.RegularExpressions.Regex]::Matches($raw, $pattern)
    $attachments = @()
    foreach ($m in $regexMatches) { $attachments += $m.Groups[1].Value.Trim() }
    $clean = ($raw -replace $pattern, '').Trim()
    [PSCustomObject]@{
        Text        = $clean
        Attachments = $attachments
    }
}

function Test-Calibrated {
    param($Click, [string]$Label)
    if ($Click.Enabled -and $Click.X -eq 0 -and $Click.Y -eq 0) {
        throw "$Label is enabled but still at the placeholder X=0, Y=0. Run Scripts\Get-MousePosition.ps1, hover over the real element, and fill in its X/Y in config.json before running this for real."
    }
}

# ---------- Main ----------
try {
    Write-Log "===== Run started ====="

    . (Join-Path $PSScriptRoot "ProviderDetection.ps1")

    if (-not $ConfigPath) { $ConfigPath = Join-Path $PSScriptRoot "..\Config\config.json" }
    $ConfigPath = (Resolve-Path $ConfigPath).Path
    $Config = Get-Content -Raw -Path $ConfigPath | ConvertFrom-Json

    # Figure out which AI provider TargetUrl belongs to, and whether it's a
    # fresh/new chat or an ongoing one.
    $Provider = Find-Provider -Config $Config -Url $Config.TargetUrl
    if (-not $Provider) {
        throw "No entry under 'Providers' in config.json matches the domain of TargetUrl ('$($Config.TargetUrl)'). Add a new Providers entry with a 'DomainMatch' for this site - see README.md 'Adding a new AI provider'."
    }
    $State = Get-ChatState -Provider $Provider -Url $Config.TargetUrl -DefaultOngoingPattern $Config.DefaultOngoingIdPattern
    $Coords = $Provider.Coordinates.$State
    if (-not $Coords) {
        throw "Provider '$($Provider.Name)' has no Coordinates.$State block in config.json."
    }
    $WindowTitleMatch = $Provider.BrowserWindowTitleMatch
    Write-Log "TargetUrl matched provider '$($Provider.Name)', detected as '$State' chat."

    Test-Calibrated -Click $Coords.PromptBoxClick -Label "$($Provider.Name) / $State / PromptBoxClick"
    if ($Config.UseFileAttachment) {
        Test-Calibrated -Click $Coords.AttachButtonClick -Label "$($Provider.Name) / $State / AttachButtonClick"
    }

    $promptFilePath = Resolve-ProjectPath $Config.PromptFilePath
    $payload = Get-PromptPayload -PromptFile $promptFilePath
    $promptText = $payload.Text

    $allAttachments = @()
    if ($Config.FilesToAttach) { $allAttachments += @($Config.FilesToAttach) }
    if ($payload.Attachments)  { $allAttachments += @($payload.Attachments) }

    if ([string]::IsNullOrWhiteSpace($promptText)) {
        throw "Prompt file is empty (after removing <<attach:...>> tags): $promptFilePath"
    }
    Write-Log "Prompt loaded ($($promptText.Length) chars). Attachments queued: $($allAttachments.Count)."

    # 1) Open the link
    if ([string]::IsNullOrWhiteSpace($Config.BrowserExecutable)) {
        Write-Log "Launching default browser -> $($Config.TargetUrl)"
        Start-Process -FilePath $Config.TargetUrl
    } else {
        Write-Log "Launching '$($Config.BrowserExecutable)' -> $($Config.TargetUrl)"
        Start-Process -FilePath $Config.BrowserExecutable -ArgumentList $Config.TargetUrl
    }
    Start-Sleep -Seconds $Config.WaitAfterLaunchSeconds

    # 2) Bring it to the front (and optionally maximize, for reliable click coordinates)
    Show-BrowserWindow -TitleMatch $WindowTitleMatch | Out-Null
    if ($Config.MaximizeBrowserWindow) { Maximize-BrowserWindow }
    Start-Sleep -Seconds $Config.WaitAfterFocusSeconds

    # 3) Attachments first (most chat UIs keep a file attached while you then type the message)
    if ($Config.UseFileAttachment -and $allAttachments.Count -gt 0) {
        foreach ($filePath in $allAttachments) {
            if (-not (Test-Path $filePath)) {
                Write-Log "WARNING: attachment not found, skipping -> $filePath"
                continue
            }
            Write-Log "Attaching -> $filePath"

            if ($Coords.AttachButtonClick.Enabled) {
                Invoke-MouseClick -X $Coords.AttachButtonClick.X -Y $Coords.AttachButtonClick.Y
            } else {
                for ($i = 0; $i -lt [int]$Coords.AttachButtonTabPresses; $i++) {
                    Send-KeysWait -Keys "{TAB}" -DelayMs 150
                }
                Send-KeysWait -Keys "{ENTER}" -DelayMs 300
            }
            Start-Sleep -Seconds $Config.WaitAfterAttachClickSeconds

            # The OS "Open" dialog's file name field is focused by default.
            Set-Clipboard -Value $filePath
            Send-KeysWait -Keys "^a" -DelayMs 150
            Send-KeysWait -Keys "^v" -DelayMs 150
            Start-Sleep -Milliseconds 500
            Send-KeysWait -Keys "{ENTER}" -DelayMs 150

            Start-Sleep -Seconds $Config.WaitAfterFileTypedSeconds
            Show-BrowserWindow -TitleMatch $WindowTitleMatch | Out-Null
        }
        Start-Sleep -Seconds 1
    }

    # 4) Focus the prompt box
    if ($Coords.PromptBoxClick.Enabled) {
        Invoke-MouseClick -X $Coords.PromptBoxClick.X -Y $Coords.PromptBoxClick.Y
    } else {
        Show-BrowserWindow -TitleMatch $WindowTitleMatch | Out-Null
    }

    # 5) Paste the prompt via the clipboard (handles special characters / line breaks / length cleanly)
    Set-Clipboard -Value $promptText
    Start-Sleep -Milliseconds 400
    Send-KeysWait -Keys "^v" -DelayMs 150
    Start-Sleep -Seconds $Config.WaitBeforeSubmitSeconds

    # 6) Submit
    Send-KeysWait -Keys $Config.SubmitKeystroke -DelayMs 150

    Write-Log "Prompt submitted."
    Write-Log "===== Run finished OK ====="
}
catch {
    Write-Log "ERROR: $($_.Exception.Message)"
    throw
}