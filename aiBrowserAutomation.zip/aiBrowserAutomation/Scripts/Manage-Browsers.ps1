<#
.SYNOPSIS
    Interactive menu for registering, listing, and removing Browsers -
    the Name -> exe-path mappings that Jobs reference by name. Register a
    browser once per PC; every job that uses it by name picks up whatever
    path is on file here.
#>

$ProjectRoot = Split-Path -Parent $PSScriptRoot
. (Join-Path $PSScriptRoot "AutomationRegistry.ps1")

$ErrorActionPreference = "Stop"

$BrowsersPath = Get-BrowsersPath -ProjectRoot $ProjectRoot
$JobsPath = Get-JobsPath -ProjectRoot $ProjectRoot

function Show-Header {
    Clear-Host
    Write-Host ""
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host "       MANAGE BROWSERS" -ForegroundColor Cyan
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host ""
}

while ($true) {
    Show-Header
    Show-BrowsersTable -BrowsersPath $BrowsersPath
    Write-Host ""
    Write-Host "  [1] Register a Browser"
    Write-Host "  [2] Delete a Browser"
    Write-Host "  [0] Back"
    Write-Host ""
    $Choice = Read-Host "Select an option"

    if ($Choice -eq "0") { break }

    try {
        switch ($Choice) {
            "1" {
                Add-BrowserInteractive -BrowsersPath $BrowsersPath | Out-Null
                Read-Host "`nPress Enter to continue"
            }
            "2" {
                $Browser = Select-BrowserFromList -BrowsersPath $BrowsersPath -ActionLabel "delete"
                if ($Browser) {
                    Remove-BrowserInteractive -BrowsersPath $BrowsersPath -JobsPath $JobsPath -Browser $Browser
                }
                Read-Host "`nPress Enter to continue"
            }
            default {
                Write-Host "`nInvalid selection." -ForegroundColor Red
                Start-Sleep -Seconds 1
            }
        }
    }
    catch {
        Write-Host "`n[ERROR] $($_.Exception.Message)" -ForegroundColor Red
        Read-Host "Press Enter to continue"
    }
}