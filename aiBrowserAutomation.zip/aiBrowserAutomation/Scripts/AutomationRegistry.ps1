<#
.SYNOPSIS
    Shared data-access and interactive-wizard functions for the Jobs and
    Browsers registries. Dot-sourced by every script that reads, writes, or
    lets the user edit jobs.json / browsers.json.

.DESCRIPTION
    Jobs and Browsers are the two small JSON registries introduced for
    multi-link / multi-browser / multi-prompt support:
      - browsers.json: a Name -> exe-path lookup, configured once per PC.
      - jobs.json: each entry ties one TaskName to one TargetUrl, one
        BrowserName (looked up in browsers.json), and one PromptFile (a
        filename inside Prompts\).
    A Job's TaskName doubles as its Windows Scheduled Task name once it's
    scheduled - see Install-ScheduledTask.ps1's -JobName parameter.
#>

function Get-JobsPath {
    param([Parameter(Mandatory)][string]$ProjectRoot)
    Join-Path $ProjectRoot "Config\jobs.json"
}

function Get-BrowsersPath {
    param([Parameter(Mandatory)][string]$ProjectRoot)
    Join-Path $ProjectRoot "Config\browsers.json"
}

function Get-AllJobs {
    param([Parameter(Mandatory)][string]$JobsPath)
    if (-not (Test-Path -LiteralPath $JobsPath)) { return @() }
    $Data = Get-Content -Raw -Path $JobsPath | ConvertFrom-Json
    return @($Data.Jobs)
}

function Save-AllJobs {
    param([Parameter(Mandatory)][string]$JobsPath, [Parameter(Mandatory)]$Jobs)
    $Data = [PSCustomObject]@{ Jobs = @($Jobs) }
    $Data | ConvertTo-Json -Depth 10 | Set-Content -Path $JobsPath -Encoding UTF8
}

function Get-JobByName {
    param([Parameter(Mandatory)][string]$JobsPath, [Parameter(Mandatory)][string]$TaskName)
    $Jobs = Get-AllJobs -JobsPath $JobsPath
    return $Jobs | Where-Object { $_.TaskName -eq $TaskName } | Select-Object -First 1
}

function Get-AllBrowsers {
    param([Parameter(Mandatory)][string]$BrowsersPath)
    if (-not (Test-Path -LiteralPath $BrowsersPath)) { return @() }
    $Data = Get-Content -Raw -Path $BrowsersPath | ConvertFrom-Json
    return @($Data.Browsers)
}

function Save-AllBrowsers {
    param([Parameter(Mandatory)][string]$BrowsersPath, [Parameter(Mandatory)]$Browsers)
    $Data = [PSCustomObject]@{ Browsers = @($Browsers) }
    $Data | ConvertTo-Json -Depth 10 | Set-Content -Path $BrowsersPath -Encoding UTF8
}

function Get-BrowserByName {
    param([Parameter(Mandatory)][string]$BrowsersPath, [Parameter(Mandatory)][string]$Name)
    $Browsers = Get-AllBrowsers -BrowsersPath $BrowsersPath
    return $Browsers | Where-Object { $_.Name -eq $Name } | Select-Object -First 1
}

function Confirm-RegistryAction {
    param([string]$Message)
    $Reply = Read-Host "$Message (y/N)"
    return $Reply -match '^(y|yes)$'
}

function Add-BrowserInteractive {
    param([Parameter(Mandatory)][string]$BrowsersPath)

    $Name = Read-Host "Browser name (e.g. Chrome, Edge, Firefox)"
    if ([string]::IsNullOrWhiteSpace($Name)) { Write-Host "Name can't be empty." -ForegroundColor Red; return $null }
    $Name = $Name.Trim()

    $Browsers = @(Get-AllBrowsers -BrowsersPath $BrowsersPath)
    if ($Browsers | Where-Object { $_.Name -eq $Name }) {
        Write-Host "A browser named '$Name' is already registered." -ForegroundColor Red
        return $null
    }

    $ExePath = Read-Host "Full path to its .exe (Enter to use this PC's system default browser)"
    $ExePath = $ExePath.Trim()
    if (-not [string]::IsNullOrWhiteSpace($ExePath) -and -not (Test-Path -LiteralPath $ExePath -PathType Leaf)) {
        Write-Host "Note: that path wasn't found on this PC right now. Saving it anyway - fix it later if needed." -ForegroundColor Yellow
    }

    $NewEntry = [PSCustomObject]@{ Name = $Name; ExePath = $ExePath }
    $Browsers = @($Browsers) + $NewEntry
    Save-AllBrowsers -BrowsersPath $BrowsersPath -Browsers $Browsers
    Write-Host "Registered '$Name'." -ForegroundColor Green
    return $NewEntry
}

function Select-BrowserForJob {
    param([Parameter(Mandatory)][string]$BrowsersPath)

    while ($true) {
        $Browsers = @(Get-AllBrowsers -BrowsersPath $BrowsersPath)
        Write-Host "`nAvailable browsers:" -ForegroundColor Cyan
        for ($i = 0; $i -lt $Browsers.Count; $i++) {
            $display = if ([string]::IsNullOrWhiteSpace($Browsers[$i].ExePath)) { "(system default)" } else { $Browsers[$i].ExePath }
            Write-Host "[$($i + 1)] $($Browsers[$i].Name)  -  $display"
        }
        Write-Host "[N] Register a new browser"
        Write-Host "[0] Cancel"
        $Sel = Read-Host "Choice"

        if ($Sel -eq "0") { return $null }
        if ($Sel -match '^[Nn]$') {
            $NewBrowser = Add-BrowserInteractive -BrowsersPath $BrowsersPath
            if ($NewBrowser) { return $NewBrowser.Name }
            continue
        }
        if ($Sel -match '^\d+$' -and [int]$Sel -ge 1 -and [int]$Sel -le $Browsers.Count) {
            return $Browsers[[int]$Sel - 1].Name
        }
        Write-Host "Invalid choice." -ForegroundColor Red
    }
}

function Select-PromptFileForJob {
    param([Parameter(Mandatory)][string]$ProjectRoot)

    $PromptsDir = Join-Path $ProjectRoot "Prompts"
    if (-not (Test-Path -LiteralPath $PromptsDir)) { New-Item -ItemType Directory -Path $PromptsDir -Force | Out-Null }

    while ($true) {
        $Files = @(Get-ChildItem -LiteralPath $PromptsDir -Filter "*.txt" -File | Sort-Object Name)
        Write-Host "`nAvailable prompt files (Prompts\):" -ForegroundColor Cyan
        for ($i = 0; $i -lt $Files.Count; $i++) {
            Write-Host "[$($i + 1)] $($Files[$i].Name)"
        }
        Write-Host "[N] Create a new prompt file"
        Write-Host "[0] Cancel"
        $Sel = Read-Host "Choice"

        if ($Sel -eq "0") { return $null }
        if ($Sel -match '^[Nn]$') {
            $NewName = Read-Host "New file name (e.g. morning-digest.txt)"
            if ([string]::IsNullOrWhiteSpace($NewName)) { continue }
            $NewName = $NewName.Trim()
            if (-not $NewName.ToLower().EndsWith(".txt")) { $NewName += ".txt" }
            $NewPath = Join-Path $PromptsDir $NewName
            if (Test-Path -LiteralPath $NewPath) {
                Write-Host "That file already exists - pick it from the list instead, or choose a different new name." -ForegroundColor Yellow
                continue
            }
            Set-Content -LiteralPath $NewPath -Value "" -Encoding UTF8
            Write-Host "Created $NewName. Opening it in Notepad - write your prompt, save, and close it to continue." -ForegroundColor Cyan
            Start-Process notepad.exe -ArgumentList "`"$NewPath`"" -Wait
            return $NewName
        }
        if ($Sel -match '^\d+$' -and [int]$Sel -ge 1 -and [int]$Sel -le $Files.Count) {
            return $Files[[int]$Sel - 1].Name
        }
        Write-Host "Invalid choice." -ForegroundColor Red
    }
}

function Add-JobInteractive {
    param(
        [Parameter(Mandatory)][string]$JobsPath,
        [Parameter(Mandatory)][string]$BrowsersPath,
        [Parameter(Mandatory)][string]$ProjectRoot
    )

    $TaskName = Read-Host "Task name for this job (its ID, and its scheduled-task name once scheduled)"
    if ([string]::IsNullOrWhiteSpace($TaskName)) { Write-Host "Task name can't be empty." -ForegroundColor Red; return $null }
    $TaskName = $TaskName.Trim()

    $Jobs = @(Get-AllJobs -JobsPath $JobsPath)
    if ($Jobs | Where-Object { $_.TaskName -eq $TaskName }) {
        Write-Host "A job named '$TaskName' already exists. Use 'Edit a Job' instead, or pick a different name." -ForegroundColor Red
        return $null
    }

    $Link = Read-Host "Link / page to open (e.g. https://claude.ai/new)"
    $Link = $Link.Trim()
    if ($Link -notmatch '^https?://') {
        Write-Host "That doesn't look like a web link - it should start with http:// or https://" -ForegroundColor Red
        return $null
    }

    $BrowserName = Select-BrowserForJob -BrowsersPath $BrowsersPath
    if (-not $BrowserName) { Write-Host "Cancelled." -ForegroundColor Cyan; return $null }

    $PromptFile = Select-PromptFileForJob -ProjectRoot $ProjectRoot
    if (-not $PromptFile) { Write-Host "Cancelled." -ForegroundColor Cyan; return $null }

    $NewJob = [PSCustomObject]@{
        TaskName    = $TaskName
        TargetUrl   = $Link
        BrowserName = $BrowserName
        PromptFile  = $PromptFile
    }

    $Jobs = @($Jobs) + $NewJob
    Save-AllJobs -JobsPath $JobsPath -Jobs $Jobs
    Write-Host "`nJob '$TaskName' saved -> $Link (browser: $BrowserName, prompt: $PromptFile)" -ForegroundColor Green
    return $NewJob
}

function Edit-JobInteractive {
    param(
        [Parameter(Mandatory)][string]$JobsPath,
        [Parameter(Mandatory)][string]$BrowsersPath,
        [Parameter(Mandatory)][string]$ProjectRoot,
        [Parameter(Mandatory)]$Job
    )

    Write-Host "`nEditing '$($Job.TaskName)'. Press Enter on any prompt to keep its current value." -ForegroundColor Cyan

    $NewLink = Read-Host "Link [$($Job.TargetUrl)]"
    if (-not [string]::IsNullOrWhiteSpace($NewLink)) {
        if ($NewLink.Trim() -notmatch '^https?://') {
            Write-Host "That doesn't look like a web link - keeping the existing one." -ForegroundColor Yellow
        } else {
            $Job.TargetUrl = $NewLink.Trim()
        }
    }

    if (Confirm-RegistryAction "Change the browser (currently '$($Job.BrowserName)')?") {
        $NewBrowserName = Select-BrowserForJob -BrowsersPath $BrowsersPath
        if ($NewBrowserName) { $Job.BrowserName = $NewBrowserName }
    }

    if (Confirm-RegistryAction "Change the prompt file (currently '$($Job.PromptFile)')?") {
        $NewPromptFile = Select-PromptFileForJob -ProjectRoot $ProjectRoot
        if ($NewPromptFile) { $Job.PromptFile = $NewPromptFile }
    }

    $Jobs = @(Get-AllJobs -JobsPath $JobsPath)
    for ($i = 0; $i -lt $Jobs.Count; $i++) {
        if ($Jobs[$i].TaskName -eq $Job.TaskName) { $Jobs[$i] = $Job }
    }
    Save-AllJobs -JobsPath $JobsPath -Jobs $Jobs
    Write-Host "Saved." -ForegroundColor Green
}

function Remove-JobInteractive {
    param(
        [Parameter(Mandatory)][string]$JobsPath,
        [Parameter(Mandatory)]$Job
    )

    $ScheduledTask = Get-ScheduledTask -TaskName $Job.TaskName -ErrorAction SilentlyContinue
    if ($ScheduledTask) {
        Write-Host "'$($Job.TaskName)' still has an active Windows scheduled task. Deleting the job will break that schedule - it'll start failing at its next run." -ForegroundColor Yellow
        if (-not (Confirm-RegistryAction "Delete the job anyway (leaving the broken schedule in place)?")) {
            Write-Host "Cancelled. Remove the schedule first (Scheduling menu) if you want to delete this job cleanly." -ForegroundColor Cyan
            return
        }
    } elseif (-not (Confirm-RegistryAction "Delete job '$($Job.TaskName)'?")) {
        Write-Host "Cancelled." -ForegroundColor Cyan
        return
    }

    $Jobs = @(Get-AllJobs -JobsPath $JobsPath) | Where-Object { $_.TaskName -ne $Job.TaskName }
    Save-AllJobs -JobsPath $JobsPath -Jobs $Jobs
    Write-Host "Deleted '$($Job.TaskName)'." -ForegroundColor Green
}

function Remove-BrowserInteractive {
    param(
        [Parameter(Mandatory)][string]$BrowsersPath,
        [Parameter(Mandatory)][string]$JobsPath,
        [Parameter(Mandatory)]$Browser
    )

    $UsedBy = @(Get-AllJobs -JobsPath $JobsPath) | Where-Object { $_.BrowserName -eq $Browser.Name }
    if ($UsedBy.Count -gt 0) {
        $Names = ($UsedBy | ForEach-Object { $_.TaskName }) -join ", "
        Write-Host "'$($Browser.Name)' is used by: $Names" -ForegroundColor Yellow
        if (-not (Confirm-RegistryAction "Delete it anyway (those jobs will fail until re-pointed at another browser)?")) {
            Write-Host "Cancelled." -ForegroundColor Cyan
            return
        }
    } elseif (-not (Confirm-RegistryAction "Delete browser '$($Browser.Name)'?")) {
        Write-Host "Cancelled." -ForegroundColor Cyan
        return
    }

    $Browsers = @(Get-AllBrowsers -BrowsersPath $BrowsersPath) | Where-Object { $_.Name -ne $Browser.Name }
    Save-AllBrowsers -BrowsersPath $BrowsersPath -Browsers $Browsers
    Write-Host "Deleted '$($Browser.Name)'." -ForegroundColor Green
}

function Show-JobsTable {
    param([Parameter(Mandatory)][string]$JobsPath)
    $Jobs = @(Get-AllJobs -JobsPath $JobsPath)
    if ($Jobs.Count -eq 0) {
        Write-Host "No jobs defined yet." -ForegroundColor Yellow
        return
    }
    $Jobs | Format-Table TaskName, TargetUrl, BrowserName, PromptFile -AutoSize
}

function Show-BrowsersTable {
    param([Parameter(Mandatory)][string]$BrowsersPath)
    $Browsers = @(Get-AllBrowsers -BrowsersPath $BrowsersPath)
    if ($Browsers.Count -eq 0) {
        Write-Host "No browsers registered yet." -ForegroundColor Yellow
        return
    }
    $Browsers | ForEach-Object {
        [PSCustomObject]@{ Name = $_.Name; ExePath = if ([string]::IsNullOrWhiteSpace($_.ExePath)) { "(system default)" } else { $_.ExePath } }
    } | Format-Table Name, ExePath -AutoSize
}

function Select-JobFromList {
    param([Parameter(Mandatory)][string]$JobsPath, [string]$ActionLabel = "act on")
    $Jobs = @(Get-AllJobs -JobsPath $JobsPath)
    if ($Jobs.Count -eq 0) {
        Write-Host "`nNo jobs defined yet." -ForegroundColor Yellow
        return $null
    }
    Write-Host "`nSelect a job to $ActionLabel`:" -ForegroundColor Cyan
    for ($i = 0; $i -lt $Jobs.Count; $i++) {
        Write-Host ("[{0}] {1}  ->  {2}  (browser: {3}, prompt: {4})" -f ($i + 1), $Jobs[$i].TaskName, $Jobs[$i].TargetUrl, $Jobs[$i].BrowserName, $Jobs[$i].PromptFile)
    }
    Write-Host "[0] Cancel"
    $Sel = Read-Host "Choice"
    if ($Sel -eq "0") { return $null }
    if ($Sel -match '^\d+$' -and [int]$Sel -ge 1 -and [int]$Sel -le $Jobs.Count) {
        return $Jobs[[int]$Sel - 1]
    }
    Write-Host "Invalid choice." -ForegroundColor Red
    return $null
}

function Select-BrowserFromList {
    param([Parameter(Mandatory)][string]$BrowsersPath, [string]$ActionLabel = "act on")
    $Browsers = @(Get-AllBrowsers -BrowsersPath $BrowsersPath)
    if ($Browsers.Count -eq 0) {
        Write-Host "`nNo browsers registered yet." -ForegroundColor Yellow
        return $null
    }
    Write-Host "`nSelect a browser to $ActionLabel`:" -ForegroundColor Cyan
    for ($i = 0; $i -lt $Browsers.Count; $i++) {
        $display = if ([string]::IsNullOrWhiteSpace($Browsers[$i].ExePath)) { "(system default)" } else { $Browsers[$i].ExePath }
        Write-Host "[$($i + 1)] $($Browsers[$i].Name)  -  $display"
    }
    Write-Host "[0] Cancel"
    $Sel = Read-Host "Choice"
    if ($Sel -eq "0") { return $null }
    if ($Sel -match '^\d+$' -and [int]$Sel -ge 1 -and [int]$Sel -le $Browsers.Count) {
        return $Browsers[[int]$Sel - 1]
    }
    Write-Host "Invalid choice." -ForegroundColor Red
    return $null
}