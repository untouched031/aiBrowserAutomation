<#
.SYNOPSIS
    Shared provider + chat-state detection logic.

.DESCRIPTION
    Dot-sourced by Invoke-AIBrowserAutomation.ps1, Test-UrlDetection.ps1
    and Calibrate-Coordinates.ps1, so detection can never drift out of
    sync between them. Operates on a plain array of provider objects
    (as loaded from Config\providers.json's "Providers" array), not on
    any particular config file's shape.

    Providers are checked in the order given; the first whose
    DomainMatch is found in the URL wins.
#>

function Convert-ToSafeArray {
    param($Value)
    if ($null -eq $Value) { return @() }
    return @($Value)
}

function Find-Provider {
    param($Providers, [string]$Url)
    foreach ($p in $Providers) {
        if ([string]::IsNullOrWhiteSpace($p.DomainMatch)) { continue }
        if ($Url -imatch [regex]::Escape($p.DomainMatch)) { return $p }
    }
    return $null
}

function Get-ChatState {
    param($Provider, [string]$Url, [string]$DefaultOngoingPattern)

    $keywords = Convert-ToSafeArray $Provider.NewChatKeywords
    if ($keywords.Count -eq 0) { $keywords = @("new") }

    foreach ($kw in $keywords) {
        if ([string]::IsNullOrWhiteSpace([string]$kw)) { continue }
        if ($Url -imatch [regex]::Escape([string]$kw)) { return "New" }
    }

    $pattern = $Provider.OngoingPattern
    if ([string]::IsNullOrWhiteSpace($pattern)) { $pattern = $DefaultOngoingPattern }
    if (-not [string]::IsNullOrWhiteSpace($pattern) -and $Url -imatch $pattern) { return "Ongoing" }

    return "New"
}