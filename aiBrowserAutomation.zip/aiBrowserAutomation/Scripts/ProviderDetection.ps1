<#
.SYNOPSIS
    Shared provider + chat-state detection logic.

.DESCRIPTION
    Dot-sourced by both Invoke-AIBrowserAutomation.ps1 and
    Test-UrlDetection.ps1, so the real run and the dry-run tester can never
    drift out of sync. See README.md "How provider + chat-state detection
    works" for the exact rules.

    Providers are checked in the order they appear in config.json; the
    first whose DomainMatch is found in the URL wins.
#>

function Convert-ToSafeArray {
    param($Value)
    if ($null -eq $Value) { return @() }
    return @($Value)
}

function Find-Provider {
    param($Config, [string]$Url)
    foreach ($p in $Config.Providers) {
        if ([string]::IsNullOrWhiteSpace($p.DomainMatch)) { continue }
        if ($Url -imatch [regex]::Escape($p.DomainMatch)) { return $p }
    }
    return $null
}

function Get-ChatState {
    param($Provider, [string]$Url, [string]$DefaultOngoingPattern)

    $keywords = Convert-ToSafeArray $Provider.NewChatKeywords
    if ($keywords.Count -eq 0) { $keywords = @("new") }

    foreach ($kw in $keywords) {
        if ([string]::IsNullOrWhiteSpace([string]$kw)) { continue }
        if ($Url -imatch [regex]::Escape([string]$kw)) { return "New" }
    }

    $pattern = $Provider.OngoingPattern
    if ([string]::IsNullOrWhiteSpace($pattern)) { $pattern = $DefaultOngoingPattern }
    if (-not [string]::IsNullOrWhiteSpace($pattern) -and $Url -imatch $pattern) { return "Ongoing" }

    return "New"
}